# SPDX-License-Identifier: Apache-2.0
"""`sprite-gen video-frames` — turn a generated clip into keyed RGBA frames.

ffmpeg extracts every frame (the clip's own fps is recorded, not assumed), then
each frame goes through the same `cutout` engine imported stills use (chroma
green/magenta -> the extract matte; `auto` reads the corners). The report carries
per-frame alpha coverage and an **edge-contact check**: a frame whose subject
touches the top/left/right edge means the model framed too tight (a jump whose
hair left the frame, 2026-09-08) and the run fails loud — the fix is a taller or
wider canvas (`video-canvas`), not a quiet crop.

An opaque edge pixel is not always the subject. When the model painted the key
a little off and part of that background survives the matte, the edge band is
"touched" by leftover *background* (2026-09-11: a (8, 162, 24) green read as
"framed too tight"). The check therefore classifies every contact pixel by its
raw colour — the declared key's hue signature (`extract.is_border_key_candidate`,
the border rule: an edge pixel is border evidence) in a piece of the keyed frame that
holds nothing else is **residual background**; anything else is the **subject**, a
key-tinted pixel joined to the subject included (its antialiased rim, the key blended
into it, reaches the band first) — and the two fail
with different messages: residual points at `video-canvas` normalization of the
base still, subject contact at a taller/wider canvas.

`--allow-subject-edge-contact` accepts the second and keeps the first: a clip made
from a `video-canvas --fit tight` frame is clipped on purpose, but a frame where only
leftover key background reaches the edge is still a keying defect. A frame where the
subject touches the edge carries key-tinted fringe pixels beside it and is accepted with
them. The contacts stay in the report.

A **speck** is not the subject either: a fleck the model drew drifting across the background,
well away from the body, that survived the matte. Every keyed frame has its specks erased
(`drop_specks`) before the edge check reads it, so a few pale pixels drifting through the edge
band far from the body are erased rather than read as the subject framed too tight. A speck is
small — under `SPECK_MIN_FRACTION` of the frame's largest component, the body — and far: more
than `SPECK_APART` of the body's height from it. Its pixels are every opaque one (what the edge
check reads), corners joining them. Near the body, small detached pieces are the subject's own
and stay: the outline's loose pixels one transparent pixel off, a shadow drawn under a shoe, a
shoe's part the matte cut loose. How many each frame lost is in its report row (`specks`).
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
import subprocess
from pathlib import Path
from typing import Any

from PIL import Image

from sprite_gen._deps import np
from sprite_gen.frames.cutout import cutout
from sprite_gen.frames.decontam import palette_from_stats
from sprite_gen.frames.extract import _border_key_candidate_field, _key_channel_split
from sprite_gen.frames.extract import _SPILL_FULL_MIN_TINT, DEFAULT_UNMIX_REACH
from sprite_gen.spec.runio import atomic_write_text

EDGE_ROWS = 4  # rows/cols inspected at each edge
# Spill (key colour the video model painted INTO the subject — a reflection on
# metal, a tint on skin near the edge). The chroma engine treats a large key-tinted
# cluster as the subject's own key-coloured material and leaves it alone; a video
# model paints reflections that are exactly that large. The still the clip was made
# from is the evidence: if the still carries (almost) no key-coloured material, every
# key tint in the clip was painted by the model and is spill.
SPILL_MODES = ("auto", "small", "full")
SPILL_FULL_FRACTION = 1.0  # every tinted cluster is spill, whatever its size
SPILL_FULL_MIN_TINT = _SPILL_FULL_MIN_TINT  # ... and whatever its strength (see extract.py)
SPILL_REFERENCE_MAX = 0.005  # the still's own key material ≤ the engine's small-cluster share → full
# The reference is keyed on its subject window only (`extract.subject_window`). A canvas padded
# for motion room is mostly key, and the matte's memory grows with every pixel it keys, so keying
# the whole canvas made the judgment grow with the padding. One keyed ring around the window is
# enough for the window to give the whole still's counts (see `subject_window`). A window over the
# pixel budget is keyed on every n-th pixel each way instead, reported as `reference_stride`, so
# no still costs more than the budget to judge.
SPILL_REFERENCE_MARGIN = 1
SPILL_REFERENCE_MAX_PIXELS = 6_000_000
EDGE_MAX_PIXELS = 0  # any opaque pixel on the top/left/right edge band = contact
# Specks (`drop_specks`). A component under SPECK_MIN_FRACTION of the frame's largest one, or under
# SPECK_MIN_PX, is small; more than SPECK_APART of the largest one's height from it, far. `video-loop`
# reads the size by the same two numbers when it erases the loose pieces of a cut (`drop_specks` with
# its own reading, see run_loop).
SPECK_MIN_FRACTION = 0.01
SPECK_MIN_PX = 8
SPECK_APART = 0.1
# Edge decontamination (`sprite_gen.frames.decontam`). A decoded frame's chroma is blurred by
# 4:2:0 while its luma is not, so frames use the video fit. One palette serves the whole clip,
# learned on the first frame, so the colours an edge may take cannot change between frames.
DECONTAM_MODES = ("off", "auto", "palette")
DECONTAM_FIT = "video"
DECONTAM_STAT_KEYS = ("changed_px", "refit_px", "tint_px", "recovered_px", "unexplained_px", "restored_px", "key_hue_capped_px")


def _require(binary: str) -> str:
    path = shutil.which(binary)
    if not path:
        raise SystemExit(f"video-frames: `{binary}` not found on PATH — install ffmpeg (brew install ffmpeg)")
    return path


def probe(clip: Path) -> dict[str, Any]:
    """The clip's moving picture and what else it carries.

    A clip can hold more than the picture: an audio track (a clip from a video MCP such as
    ZCRE always has one, and so does `sprite-gen video` unless `--no-audio`) and a cover image,
    a one-frame mjpeg stream marked `attached_pic`. The frames come from the first video stream
    that is not a cover (`stream_index`); the audio is counted and never extracted."""
    ffprobe = _require("ffprobe")
    proc = subprocess.run(
        [ffprobe, "-v", "error", "-show_entries", "stream=index,codec_type,codec_name,pix_fmt,width,height,r_frame_rate,nb_frames",
         "-show_entries", "stream_disposition=attached_pic", "-show_entries", "format=duration", "-of", "json", str(clip)],
        capture_output=True, text=True,
    )
    if proc.returncode != 0:
        raise SystemExit(f"video-frames: ffprobe failed on {clip}: {proc.stderr.strip()[:300]}")
    data = json.loads(proc.stdout)
    streams = data.get("streams") or []
    pictures = [s for s in streams if s.get("codec_type") == "video" and not (s.get("disposition") or {}).get("attached_pic")]
    if not pictures:
        raise SystemExit(f"video-frames: {clip} has no video stream (only {', '.join(sorted({str(s.get('codec_type')) for s in streams})) or 'nothing'})")
    stream = pictures[0]
    num, den = (stream.get("r_frame_rate") or "24/1").split("/")
    fps = float(num) / float(den or 1)
    return {"width": stream.get("width"), "height": stream.get("height"), "fps": fps,
            "nb_frames": int(stream["nb_frames"]) if str(stream.get("nb_frames", "")).isdigit() else None,
            "duration": float(data.get("format", {}).get("duration") or 0),
            "stream_index": stream.get("index"), "codec": stream.get("codec_name"), "pix_fmt": stream.get("pix_fmt"),
            "audio_streams": sum(1 for s in streams if s.get("codec_type") == "audio"),
            "cover_streams": sum(1 for s in streams if s.get("codec_type") == "video" and (s.get("disposition") or {}).get("attached_pic"))}


def extract(clip: Path, raw_dir: Path, stream_index: int | None = None) -> list[Path]:
    """Every frame of the clip's picture as PNG; `stream_index` names that stream (`probe`)."""
    ffmpeg = _require("ffmpeg")
    raw_dir.mkdir(parents=True, exist_ok=True)
    for old in raw_dir.glob("frame-*.png"):
        old.unlink()
    pick = ["-map", f"0:{stream_index}"] if stream_index is not None else []
    proc = subprocess.run([ffmpeg, "-v", "error", "-y", "-i", str(clip), *pick, str(raw_dir / "frame-%04d.png")], capture_output=True, text=True)
    if proc.returncode != 0:
        raise SystemExit(f"video-frames: ffmpeg failed on {clip}: {proc.stderr.strip()[:300]}")
    files = sorted(raw_dir.glob("frame-*.png"))
    if not files:
        raise SystemExit(f"video-frames: ffmpeg wrote no frames for {clip}")
    return files


def _components(solid: np.ndarray, *, diagonal: bool = False) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """The components of a boolean picture, as runs of each row: (row, first column, column past the
    last, component of the run, pixels per component). A run touches a run of the row above when their
    columns overlap (4-connected), or with `diagonal` also when they meet at a corner (8-connected)."""
    reach = 1 if diagonal else 0
    rows, width = solid.shape
    edges = np.diff(np.pad(solid.astype(np.int8), ((0, 0), (1, 1))), axis=1)
    ys, starts = np.nonzero(edges == 1)
    stops = np.nonzero(edges == -1)[1]
    parent = list(range(len(ys)))

    def root(k: int) -> int:
        while parent[k] != k:
            parent[k] = parent[parent[k]]
            k = parent[k]
        return k

    bounds = np.searchsorted(ys, np.arange(rows + 1))
    for y in range(1, rows):
        a, a_end = int(bounds[y - 1]), int(bounds[y])
        b, b_end = a_end, int(bounds[y + 1])
        while a < a_end and b < b_end:
            if starts[a] < stops[b] + reach and starts[b] < stops[a] + reach:
                ra, rb = root(a), root(b)
                if ra != rb:
                    parent[max(ra, rb)] = min(ra, rb)
            if stops[a] < stops[b]:
                a += 1
            else:
                b += 1
    labels = np.array([root(k) for k in range(len(ys))], dtype=np.int64)
    sizes = np.bincount(labels, weights=stops - starts, minlength=len(ys)).astype(np.int64)
    return ys, starts, stops, labels, sizes


def _near(mask: np.ndarray, reach: int) -> np.ndarray:
    """Every pixel within `reach` px of `mask`, each way and diagonally (a square of side 2 reach + 1)."""
    for axis in (0, 1):
        n = mask.shape[axis]
        total = np.cumsum(np.pad(mask.astype(np.int32), [(reach + 1, reach) if a == axis else (0, 0) for a in (0, 1)]), axis=axis)
        mask = (np.take(total, np.arange(2 * reach + 1, 2 * reach + 1 + n), axis=axis)
                - np.take(total, np.arange(n), axis=axis)) > 0
    return mask


def drop_specks(image: Image.Image, *, alpha_over: int = 0, diagonal: bool = True,
                apart: float = SPECK_APART) -> tuple[Image.Image, int]:
    """Erase the specks: (the image, components erased). A component is the pixels over `alpha_over`,
    joined side by side (and at corners with `diagonal`); a speck is one under SPECK_MIN_FRACTION of
    the largest, or under SPECK_MIN_PX, whose every pixel is more than `apart` of the largest one's
    height from it (0: wherever it is). An image with no speck comes back as it was given, the same
    object; otherwise a copy with the specks' pixels set to (0, 0, 0, 0)."""
    rgba = np.asarray(image.convert("RGBA"))
    ys, starts, stops, labels, sizes = _components(rgba[..., 3] > alpha_over, diagonal=diagonal)
    if not len(ys):
        return image, 0
    largest = int(sizes.argmax())
    small = sizes < max(SPECK_MIN_PX, int(sizes[largest]) * SPECK_MIN_FRACTION)
    small[np.setdiff1d(np.arange(len(sizes)), labels)] = False  # only the roots are components
    if small.any() and apart > 0:
        body = labels == largest
        reach = int(apart * (int(ys[body].max()) - int(ys[body].min()) + 1))
        near = np.zeros(rgba.shape[:2], dtype=bool)
        for y, x0, x1 in zip(ys[body], starts[body], stops[body]):
            near[y, x0:x1] = True
        near = _near(near, reach)
        for y, x0, x1, label in zip(ys, starts, stops, labels):
            if small[label] and near[y, x0:x1].any():
                small[label] = False
    if not small.any():
        return image, 0
    out = rgba.copy()
    for y, x0, x1 in zip(ys[small[labels]], starts[small[labels]], stops[small[labels]]):
        out[y, x0:x1] = 0
    return Image.fromarray(out, "RGBA"), int(small.sum())


def edge_contact(image: Image.Image) -> dict[str, int]:
    """Opaque pixels in the top/left/right edge bands (the floor edge is expected contact)."""
    alpha = image.convert("RGBA").getchannel("A")
    w, h = alpha.size
    px = alpha.load()
    top = sum(1 for y in range(min(EDGE_ROWS, h)) for x in range(w) if px[x, y] > 0)
    left = sum(1 for x in range(min(EDGE_ROWS, w)) for y in range(h) if px[x, y] > 0)
    right = sum(1 for x in range(max(0, w - EDGE_ROWS), w) for y in range(h) if px[x, y] > 0)
    return {"top": top, "left": left, "right": right}


def classify_edge_contact(raw: Image.Image, keyed: Image.Image, chroma_key: tuple[int, int, int] | None) -> dict[str, int]:
    """Split the opaque edge-band pixels into `subject` and `residual` (leftover key background).

    A contact pixel whose *raw* colour carries the declared key's hue signature
    (`is_border_key_candidate`) is either background the matte failed to erase or the subject's
    own rim: a body reaching the band brings its antialiased edge, the key blended into it, there
    first. It is residual only when the opaque piece of the keyed frame it belongs to — its opaque
    pixels, corners joining them, the pieces `drop_specks` reads — holds no pixel off the key's
    signature: background on its own. Joined to one, it is the subject's. Without a chroma key
    (matte route) every contact is the subject.
    """
    alpha = np.asarray(keyed.convert("RGBA"))[..., 3]
    h, w = alpha.shape
    band = np.zeros((h, w), dtype=bool)
    band[:EDGE_ROWS, :] = True
    band[:, :EDGE_ROWS] = True
    band[:, max(0, w - EDGE_ROWS):] = True
    opaque = alpha > 0
    contact = band & opaque
    total = int(contact.sum())
    keyed_channels, unkeyed_channels = _key_channel_split(chroma_key) if chroma_key is not None else ([], [])
    if not total or not keyed_channels:
        return {"subject": total, "residual": 0}
    keyish = _border_key_candidate_field(np.asarray(raw.convert("RGB"), dtype=np.int32), keyed_channels, unkeyed_channels)
    suspect = contact & keyish
    if not suspect.any():
        return {"subject": total, "residual": 0}
    ys, starts, stops, labels, _ = _components(opaque, diagonal=True)
    piece = np.zeros((h, w), dtype=np.int64)
    for y, x0, x1, label in zip(ys, starts, stops, labels):
        piece[y, x0:x1] = label
    owned = np.zeros(len(ys), dtype=bool)  # pieces holding a pixel off the key's signature
    owned[piece[opaque & ~keyish]] = True
    residual = int((suspect & ~owned[piece]).sum())
    return {"subject": total - residual, "residual": residual}


def _reference_window(reference: Path, key: str) -> tuple[str, Image.Image | None, tuple[int, int, int] | None, dict[str, Any]]:
    """What `decide_spill` keys: (key kind, subject window or None, painted key, report fields).

    The painted key is read on the whole still, whose borders the window no longer has. The
    still is kept in the mode it was decoded in and read a band of rows at a time; only the
    window is converted to RGBA, and the full-size image is released before it is keyed.
    """
    from sprite_gen.frames.cutout import KEY_TARGETS, _EXTRACT_KEY_THRESHOLD, _corner_average, _detect_key_kind
    from sprite_gen.frames.extract import detect_background_key_rgb, subject_window

    image = Image.open(reference)
    image.load()
    kind = _detect_key_kind(_corner_average(image)) if key == "auto" else key
    if kind not in ("green", "magenta"):
        return kind, None, None, {}
    target = KEY_TARGETS[kind]
    painted = detect_background_key_rgb(image, target)
    box = subject_window(image, target, _EXTRACT_KEY_THRESHOLD, SPILL_REFERENCE_MARGIN, painted)
    facts: dict[str, Any] = {"reference_size": list(image.size), "reference_window": list(box) if box else None,
                             "reference_stride": 1}
    if box is None:  # every pixel is within the hard cut of the key: nothing of the still survives
        return kind, None, painted, facts
    window = image.crop(box).convert("RGBA")
    stride = math.ceil(math.sqrt(window.width * window.height / SPILL_REFERENCE_MAX_PIXELS))
    if stride > 1:
        window = Image.fromarray(np.ascontiguousarray(np.asarray(window)[::stride, ::stride]))
        facts["reference_stride"] = stride
    return kind, window, painted, facts


def decide_spill(reference: Path, key: str) -> dict[str, Any]:
    """`auto`: key the reference still with the same matte and measure its own
    key-coloured material. None worth the name → `full`; some → `small`.

    Only the still's subject window is keyed (`reference_window`); a window over
    `SPILL_REFERENCE_MAX_PIXELS` is keyed on every `reference_stride`-th pixel each way."""
    from sprite_gen.frames.cutout import KEY_TARGETS, extract_route
    from sprite_gen.frames.extract import key_material_pixels

    kind, window, painted, facts = _reference_window(reference, key)
    if kind not in ("green", "magenta"):
        return {"mode": "small", "reference": str(reference), "reason": f"key {kind!r} has no spill pass"}
    material = subject = 0
    if window is not None:
        keyed, _ = extract_route(window, kind, background_key=painted)
        # judged at the bar `full` would treat with, so a subject that owns a mild key tint
        # is not first called "no key material" and then scrubbed of it
        material, subject = key_material_pixels(keyed, KEY_TARGETS[kind], SPILL_FULL_MIN_TINT,
                                                require_hue=True, ignore_fringe=DEFAULT_UNMIX_REACH)
    share = material / subject if subject else 0.0
    mode = "full" if share <= SPILL_REFERENCE_MAX else "small"
    return {"mode": mode, "reference": str(reference), "key": kind, "key_material_px": material,
            "subject_px": subject, "key_material_share": round(share, 5), "share_max": SPILL_REFERENCE_MAX,
            "material_metric": "key-channel-excess", "reference_fringe_ignored_px": DEFAULT_UNMIX_REACH,
            "reference_fringe_policy": "dark-only", **facts}


def key_frames(
    raw_files: list[Path],
    keyed_dir: Path,
    *,
    key: str = "auto",
    check_edges: bool = True,
    spill: str = "small",
    allow_subject: bool = False,
    decontam: str = "off",
) -> dict[str, Any]:
    if spill not in ("small", "full"):
        raise SystemExit(f"video-frames: key_frames takes a resolved spill mode (small|full), got {spill!r}")
    if decontam not in DECONTAM_MODES:
        raise SystemExit(f"video-frames: unknown --decontam {decontam!r}; expected one of {', '.join(DECONTAM_MODES)}")
    clip_palette: dict[str, Any] | None = None
    decontam_first: dict[str, Any] | None = None
    decontam_totals = {name: 0 for name in DECONTAM_STAT_KEYS}
    decontam_applied = 0
    # Full correction lowers the tint threshold as well as lifting the size cap.
    spill_max = SPILL_FULL_FRACTION if spill == "full" else None
    spill_tint = SPILL_FULL_MIN_TINT if spill == "full" else None
    keyed_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    contacts: list[dict[str, Any]] = []
    for src in raw_files:
        dst = keyed_dir / src.name
        stats = cutout(src, dst, key=key, spill_max_fraction=spill_max, spill_min_tint=spill_tint,
                       spill_require_hue=spill == "full", decontam=decontam, decontam_fit=DECONTAM_FIT,
                       decontam_palette=clip_palette, decontam_edge_band=EDGE_ROWS)
        image = Image.open(dst).convert("RGBA")
        # The specks go before anything reads the frame: the edge band, the coverage, the loop.
        image, specks = drop_specks(image)
        if specks:
            image.save(dst)
        hist = image.getchannel("A").histogram()
        w, h = image.size
        alpha_zero_pct = round(100 * hist[0] / (w * h), 2)
        row = {"frame": src.name, "alpha_zero_pct": alpha_zero_pct, "route": stats.get("route"), "specks": specks}
        if decontam != "off":
            done = stats["decontam"]
            if done.get("applied"):
                if clip_palette is None:
                    clip_palette = palette_from_stats(done)
                    decontam_first = done | {"frame": src.name}
                row["decontam"] = {name: done[name] for name in DECONTAM_STAT_KEYS}
                for name in DECONTAM_STAT_KEYS:
                    decontam_totals[name] += int(done[name])
                decontam_applied += 1
            else:
                row["decontam"] = {"applied": False, "reason": done.get("reason")}
        if check_edges:
            contact = edge_contact(image)
            if any(v > EDGE_MAX_PIXELS for v in contact.values()):
                chroma = stats.get("chroma_key")
                contact.update(classify_edge_contact(Image.open(src), image, tuple(chroma) if chroma else None))
                contact["key_painted"] = stats.get("chroma_key_painted")
                contacts.append({"frame": src.name, **contact})
            row["edge"] = contact
        if hist[0] == 0:
            raise SystemExit(f"video-frames: {src.name} keyed to 0% transparency — the background is not the chroma key")
        rows.append(row)
    report = {
        "frames": len(rows),
        "alpha_zero_pct_min": min(r["alpha_zero_pct"] for r in rows),
        "alpha_zero_pct_max": max(r["alpha_zero_pct"] for r in rows),
        "specks": {"dropped": sum(r["specks"] for r in rows), "frames": sum(1 for r in rows if r["specks"]),
                   "min_fraction": SPECK_MIN_FRACTION, "min_px": SPECK_MIN_PX, "apart": SPECK_APART},
        "edge_contacts": contacts,
        "edge_policy": "off" if not check_edges else ("subject-allowed" if allow_subject else "refuse"),
        "rows": rows,
    }
    if decontam != "off" and decontam_first is not None:
        report["decontam"] = {
            "mode": decontam,
            "fit": DECONTAM_FIT,
            "palette_source": f"clip (learned on {decontam_first['frame']})",
            "palette": decontam_first["palette"],
            "palette_keyfree": decontam_first["palette_keyfree"],
            "key_material_share": decontam_first["key_material_share"],
            "material_spread": decontam_first["material_spread"],
            "edge_band": decontam_first["edge_band"],
            "applied_frames": decontam_applied,
            "totals": decontam_totals,
        }
    else:
        report["decontam"] = {"mode": decontam, "applied_frames": 0}
    if contacts and check_edges:
        if not allow_subject:
            raise SystemExit(_edge_contact_message(contacts))
        # Only a frame where the key alone reaches the edge is leftover background. Where the
        # subject touches it too, the key-tinted pixels beside it are its antialiased fringe or
        # a reflection of the key on it (a silver armour on green) — the same reading
        # `_edge_contact_message` gives a mixed contact.
        residual = [c for c in contacts if c["residual"] > 0 and c["subject"] == 0]
        if residual:
            raise SystemExit(_residual_message(residual))
    return report


def _worst(contacts: list[dict[str, Any]]) -> tuple[dict[str, Any], str]:
    worst = max(contacts, key=lambda c: c["top"] + c["left"] + c["right"])
    return worst, f"(worst {worst['frame']}: top {worst['top']} / left {worst['left']} / right {worst['right']} px)"


def _residual_message(contacts: list[dict[str, Any]]) -> str:
    worst, where = _worst(contacts)
    painted = tuple(worst["key_painted"]) if worst.get("key_painted") else None
    return (
        f"video-frames: leftover chroma background reaches the frame edge in {len(contacts)} frame(s) {where} — "
        f"the key survived the matte (painted background {painted}); this is background, not the subject: "
        "normalize the base still with `sprite-gen video-canvas` (repaints the flat background to the exact key) "
        "and regenerate the clip"
    )


def _edge_contact_message(contacts: list[dict[str, Any]]) -> str:
    """Residual background and a clipped subject are different defects with different fixes."""
    worst, where = _worst(contacts)
    subject_frames = [c for c in contacts if c["subject"] > 0]
    residual_frames = [c for c in contacts if c["residual"] > 0]
    if not subject_frames:
        return _residual_message(contacts)
    message = (
        f"video-frames: the subject touches the frame edge in {len(subject_frames)} frame(s) {where} — "
        "the clip was framed too tight; regenerate from a taller/wider canvas (`sprite-gen video-canvas`) "
        "or pass --allow-edge-contact to accept the clipping"
    )
    if residual_frames:
        message += f"; {len(residual_frames)} frame(s) also carry leftover chroma background at the edge (`residual` in the report)"
    return message


def run_frames(clip: Path, out_dir: Path, *, key: str, allow_edge_contact: bool, report_path: Path | None, spill: str = "small", reference: Path | None = None, allow_subject_edge_contact: bool = False, decontam: str = "off", source_manifest: Path | None = None) -> dict[str, Any]:
    if source_manifest is not None and reference is None:
        raise SystemExit("video-frames: --source-manifest needs --reference (the source canvas)")
    if source_manifest is not None:
        target = (report_path or out_dir / "frames.report.json").expanduser().resolve()
        receipt = Path(source_manifest).expanduser().resolve()
        if (receipt in (target, clip.expanduser().resolve(), Path(reference).expanduser().resolve())
                or receipt.is_relative_to((out_dir / "keyed").expanduser().resolve())
                or receipt.is_relative_to((out_dir / "raw").expanduser().resolve())):
            raise SystemExit("video-frames: source manifest cannot overwrite source files or report")
    if spill not in SPILL_MODES:
        raise SystemExit(f"video-frames: unknown --spill {spill!r}; expected one of {', '.join(SPILL_MODES)}")
    if spill == "auto" and reference is None:
        raise SystemExit("video-frames: --spill auto needs --reference (the still the clip was made from)")
    if decontam not in DECONTAM_MODES:
        raise SystemExit(f"video-frames: unknown --decontam {decontam!r}; expected one of {', '.join(DECONTAM_MODES)}")
    clip = clip.expanduser().resolve()
    if not clip.is_file():
        raise SystemExit(f"video-frames: clip not found: {clip}")
    out_dir = out_dir.expanduser().resolve()
    meta = probe(clip)
    raw_dir = out_dir / "raw"
    keyed_dir = out_dir / "keyed"
    decision = decide_spill(Path(reference).expanduser().resolve(), key) if spill == "auto" else {"mode": spill, "reason": "explicit"}
    files = extract(clip, raw_dir, meta["stream_index"])
    report = key_frames(files, keyed_dir, key=key, check_edges=not allow_edge_contact, spill=decision["mode"], allow_subject=allow_subject_edge_contact, decontam=decontam)
    payload = {"kind": "sprite-gen-video-frames-report", "clip": str(clip), "out_dir": str(out_dir), "raw_dir": str(raw_dir), "keyed_dir": str(keyed_dir), "key": key, "spill": decision, **meta, **report}
    target = (report_path or (out_dir / "frames.report.json")).expanduser().resolve()
    if source_manifest is not None:
        from sprite_gen.video.evidence import engine_identity
        payload["producer"] = engine_identity()
    atomic_write_text(target, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    if source_manifest is not None:
        from sprite_gen.video import source
        Path(source_manifest).parent.mkdir(parents=True, exist_ok=True)
        record = source.manifest(clip=clip, canvas=Path(reference), frames_report=target,
                                 files=sorted(keyed_dir.glob("*.png")),
                                 timestamps=source.timestamps(clip, meta["stream_index"]))
        atomic_write_text(Path(source_manifest), json.dumps(record, indent=2, allow_nan=False) + "\n")
    payload["report"] = str(target)
    return payload


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--clip", required=True, type=Path, help="mp4 from `sprite-gen video`, or one made elsewhere from a `video-canvas` still (a video MCP such as ZCRE); an audio track and a cover image are left out")
    parser.add_argument("--out-dir", required=True, type=Path, help="writes raw/ and keyed/ here")
    parser.add_argument("--key", choices=("auto", "green", "magenta", "white"), default="auto", help="background key (auto reads the corners)")
    parser.add_argument("--allow-edge-contact", action="store_true", help="accept any opaque pixel at the top/left/right edge (subject and leftover key background alike)")
    parser.add_argument("--allow-subject-edge-contact", action="store_true", help="accept the subject touching the top/left/right edge (a `video-canvas --fit tight` clip) but still refuse leftover key background there")
    parser.add_argument("--report", type=Path, help="report JSON (default <out-dir>/frames.report.json)")
    parser.add_argument("--source-manifest", type=Path, help="write exact clip/canvas/keyed-file digests and source timestamps (requires --reference)")
    parser.add_argument("--spill", choices=SPILL_MODES, default="small", help="small: correct only small key-tinted clusters (default); full: every key tint in the subject is spill; auto: decide from --reference")
    parser.add_argument("--reference", type=Path, help="the still the clip was made from (required by --spill auto)")
    parser.add_argument("--decontam", choices=DECONTAM_MODES, default="off", help="off: the matte as is (default); palette: re-explain key-tinted edges with the subject's own colours (one palette per clip, video fit); auto: the same where it applies, reasons recorded where not")


def run(**kwargs: object) -> int:
    payload = run_frames(Path(str(kwargs["clip"])), Path(str(kwargs["out_dir"])), key=str(kwargs.get("key") or "auto"),
                         allow_edge_contact=bool(kwargs.get("allow_edge_contact")), report_path=kwargs.get("report"),  # type: ignore[arg-type]
                         spill=str(kwargs.get("spill") or "small"), reference=kwargs.get("reference"),  # type: ignore[arg-type]
                         allow_subject_edge_contact=bool(kwargs.get("allow_subject_edge_contact")),
                         decontam=str(kwargs.get("decontam") or "off"), source_manifest=kwargs.get("source_manifest"))  # type: ignore[arg-type]
    summary = {k: payload[k] for k in ("clip", "keyed_dir", "width", "height", "fps", "frames", "codec", "pix_fmt", "audio_streams", "alpha_zero_pct_min", "alpha_zero_pct_max", "edge_contacts", "edge_policy", "spill", "report")}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="sprite-gen video-frames", description=__doc__)
    add_arguments(parser)
    return run(**vars(parser.parse_args(argv)))


if __name__ == "__main__":
    raise SystemExit(main())
