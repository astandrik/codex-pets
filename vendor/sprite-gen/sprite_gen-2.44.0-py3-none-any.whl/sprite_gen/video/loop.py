# SPDX-License-Identifier: Apache-2.0
"""`sprite-gen video-loop` — cut one seamless cycle out of keyed frames and emit the
loop as cycle frames, a horizontal strip (+ metadata), a transparent GIF and a WebP.

Period first, seam second. A single-start "most similar later frame" search lands
on the 1.5-cycle look-alike of a gait (legs swapped) and produces a loop that
hitches at the wrap (2026-09-08 실측: side walk picked 39 frames where the period
was 28, run picked 25 where it was 17). So the true period is read from the
GLOBAL profile `P[L] = mean_j |f[j] - f[j+L]|` — its deepest local minimum inside
the state's window — and only then is the start chosen as the best seam for that
period. Gaits also compare the motion around the two cycle boundaries so an
accidental single-frame seam cannot outrank a coherent repeat. Idle motion is
tiny and not strictly periodic: its window is opened to
most of the clip, where the seam is lowest.

The deepest repeat can hold two cycles (a clip drawn on twos whose cycle is an odd number of
frames repeats better two cycles on than one), but nothing here cuts shorter than it on the
pixels' word: a gait's half step with the legs drawn alike is the same picture as a true cycle
half a drawing late. The half and the third of the period are screened and recorded
(`cycle.fundamental`, sprite_gen/video/period.py); `video-cycle-align` stops a set on a loop the
screen suspects, and only a count given to it (`--cycles`) takes one cycle out of that loop.

Everything downstream is measured, never assumed: the seam ratio (wrap distance
over the mean adjacent-frame distance inside the cycle) gates the run, the GIF and
WebP are re-opened and verified (frame count, loop flag, transparent corners,
no stale RGB under alpha 0). The strip metadata carries `body_h` — the standing
body height (median per-frame bbox height) — so a consumer can scale a jump strip,
whose cells include air room, to the same on-screen body size as a walk strip.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from typing import Any

from PIL import Image

from sprite_gen._deps import np
from sprite_gen.spec.runio import atomic_write_text
from sprite_gen.util.gif_utils import save_clean_gif
from sprite_gen.util.resample import resize_cell
from sprite_gen.video import motion_anchor, auto_motion, local_cycle, gait_fallback
from sprite_gen.video import held as held_mod
from sprite_gen.video import legs as legs_mod
from sprite_gen.video import period as period_mod
from sprite_gen.video import repair as repair_mod
from sprite_gen.video import rife as rife_mod
from sprite_gen.video.interpolation_quality import ghost_screen
from sprite_gen.video import evidence as evidence_mod
from sprite_gen.video.frames import drop_specks

ANALYSIS_SIZE = 96  # thumbnail edge for the distance matrix
STRIP_MAX_CELLS = 64  # upper bound on cells even when they are narrow
STRIP_MAX_WIDTH = 32000  # Chrome refuses images wider than ~32767 px; the cap is on PIXELS — a 650 px cell allows only 49 cells (2026-09-09 wolf idle: 64 cells = 41,664 px, unrenderable)
STRIP_MAX_HEIGHT = 520
SEAM_RATIO_MAX = 2.0  # loop seam / mean adjacent distance inside the cycle
PERIODICITY_MIN = 0.15  # the period must dip at least 15% below the profile mean (flat profile = no repeat)
# Where the gait fallback writes the frames it scaled back (removed once the strip is built).
FALLBACK_FRAMES_DIR = ".gait-fallback-frames"
GIF_FPS_DEFAULT = 24.0  # GIF/WebP playback density = the source rate: every cycle frame is kept, a fast action never looks slow (12 made a jump read sluggish, 2026-09-09)
GIF_FRAMES_MIN = 4
ONE_SHOT_MIN_CONTRAST = 3.0  # one-shot: the excursion peak must stand this far above the rest-pose noise (in MADs)
# Endpoint-relative departure in units of mean subject pixel mass. Contrast against
# the whole distance profile can miss a held action, so mass is a second explicit
# acceptance rule. Sustained excursion and departure/step gates reject stand jitter.
ONE_SHOT_MIN_MOVED = 0.4
ONE_SHOT_MIN_COHERENCE = 3.0  # departure must exceed three ordinary playback steps
ONE_SHOT_MIN_ACTIVE = 4  # isolated keying/jitter spikes are not a performed action
ONE_SHOT_PAD = 2  # one-shot: rest frames kept on each side of the excursion so the seam is rest -> rest
CYCLE_MODES = ("auto", "periodic", "one-shot", "fixed", "pinned")
# --cycle pinned: the clip was asked to end on its first frame (first-last mode). A re-rendered
# first frame is never byte-identical to its source; on the analysis thumbnail (mean absolute
# RGBA difference, 0..1) it lands within this of it, well under one frame of visible motion.
PIN_NOISE_MAX = 0.005
ONE_SHOT_MIN_LEN = 4  # a one-shot's length is the clip's own fact; only a degenerate cut is refused
# Gait half-period guard. A walk cycle is two steps; when the two halves look alike in
# pixels (legs hidden by a costume, near/far leg not distinguishable) the half period dips
# as deep as — or deeper than — the full one, and the "smallest minimum within 15 %"
# rule picks one step. Pixels cannot settle that case, so a duration prior does: a gait
# period shorter than the state's floor is treated as one step, and the doubled period is
# taken when it repeats about as well. The cost is asymmetric — a wrongly doubled cycle
# is still a clean two-cycle loop, a halved one walks on one leg.
GAIT_DOUBLE_TOL = 0.25
GAIT_DOUBLE_SEARCH = 3  # frames either side of 2x the step where the full gait's own minimum may sit
GAIT_NEAR_EXACT_STEP_FRACTION = 0.10  # no ambiguity extension when repeat error is tiny compared with a playback step
# `--steps`: how many steps the cut `--anchor motion-auto` takes holds, as counted by whoever looked at
# it (docs/loop-repair.md section 3, "The step screen"). 1 cuts again two of its lengths long, 2 keeps it.
STEPS = (1, 2)
# A cut two steps long (one cycle) that the clip holds less than this share of a cycle past is cut and
# warned about (`cycle.coverage`): its repeat is barely in the clip, and the seam gate says whether it
# closes. The search itself sees a window repeat only with a quarter of its length past it in the clip,
# so a cut under this was taken on the count alone (local_cycle.counted).
COVERAGE_MIN = 0.25
ANCHOR_MODES = ("none", "feet", "body", "motion", "motion-auto")
BODY_ANCHOR_BAND = 0.6  # --anchor body reads the wrap offset from the top 60 % of the first frame's box: head and torso, not the legs
BODY_ANCHOR_SEARCH = 24  # px either side searched for the last frame's horizontal offset against the first
FOOT_BAND = legs_mod.FOOT_BAND  # fraction of the frame's own height, measured up from its lowest opaque row
# Jump-frame repair (docs/loop-repair.md section 2). auto: walk and run loops get a RIFE frame in
# place of each frame that follows a jump, and a loop that needs one where no RIFE is installed is
# cut as filmed with a warning (a walk that cut before RIFE existed still cuts); on: the same, but
# no RIFE fails the loop — a caller that asked for the repair is never handed less; off: the loop
# is cut as filmed, and says so.
REPAIR_MODES = ("auto", "on", "off")
SIZE_HOLD_MODES = ("auto", "off")
FACINGS = ("right", "left")
# Where `video-cycle-align` keeps the cut as filmed (sprite_gen/video/align.py). A new cut makes
# the kept one stale, so writing the cycle removes it: an alignment after a re-cut (say, once RIFE
# is installed and the jumps are repaired) reads the new cut, not the old one.
CYCLE_SOURCE_DIR = "cycle.source"
# The strip as it was before `video-follow` moved a region of it; a later follow-through reads
# from it, and a new cut or alignment removes it (docs/video-pipeline.md section 6).
FOLLOW_SOURCE = "follow.source.png"


# A gait's period is a fact about the body, not about how long the clip runs: the
# same walker takes the same ~1 s stride in a 3 s clip and a 6 s clip. A window cut
# from the clip length (the fractions below) shrank with the clip and, at 3 s, put a
# 1.0-1.3 s stride above the walk ceiling (measured 2026-09-18: one of four walks refused
# outright, another cut at a half step). Gait states therefore take their window in
# seconds — physical bounds on how fast and how slow a locomotion cycle can be — capped
# above by half the clip, the most a detector can *confirm* repeats (a cycle must be seen
# twice to be a cycle at all). The ceiling is a bound in seconds and not simply "half
# the clip" because the periodicity gate compares the period's dip with the profile's
# mean over the whole window: a ceiling that grows with the clip drags in long, sparsely
# sampled lags, inflates that mean, and let a clip with ONE hop and a jittering stand
# pass as a walk (measured 2026-09-20 on the one-shot fixture: 0.23 with a half-clip
# ceiling, 0.03 with 1.6 s). The half-period guard (`min_seconds`) is unchanged.


@dataclass(frozen=True)
class LoopProfile:
    min_frac: float  # window as a fraction of the clip's frame count (non-gait states)
    max_frac: float
    why: str
    periodic: bool = True  # gate: the profile must show a real period (idle is exempt)
    one_shot_ok: bool = False  # the state is an action that may legitimately happen once (jump, attack) -> one-shot detector may take over
    gait: bool = False  # locomotion: a period must hold two steps, so the half-period guard applies
    min_seconds: float = 0.0  # gait floor: a detected period shorter than this is treated as one step
    window_seconds: tuple[float, float] | None = None  # gait states: period bounds in seconds (see above)

    action_seconds: float | None = None  # partial repeats need observed context, not a clip fraction

    def window(self, n: int, fps: float) -> tuple[int, int]:
        """Period-length window [lo, hi] in frames for a clip of `n` keyed frames.

        Gait states: `window_seconds`, the ceiling capped at half the clip. Everything
        else uses clip-length fractions, except attack: its action-time ceiling retains
        actual comparison context and uses a coverage-dependent periodicity floor)."""
        if self.action_seconds is not None:
            lo = max(4, round(n * self.min_frac))
            context = max(8, math.ceil(fps * 0.5))
            return lo, min(round(self.action_seconds * fps), n - context)
        if self.window_seconds is not None:
            lo = max(4, round(self.window_seconds[0] * fps))
            return lo, max(lo + 2, min(n // 2, round(self.window_seconds[1] * fps)))
        lo = max(4, round(n * self.min_frac))
        return lo, max(lo + 2, round(n * self.max_frac))


# State -> detection window. Non-gait profiles are fractions of the clip length so 6 s and
# 10 s clips both work; gait profiles use `window_seconds` (see above). Walk: measured
# strides 0.58-1.5 s (2026-09-09..20, seven bodies); run: 0.67-0.8 s.
STATE_PROFILES: dict[str, LoopProfile] = {
    "idle": LoopProfile(0.60, 0.95, "breathing is slow and not strictly periodic; the lowest seam is a long window", periodic=False),
    "walk": LoopProfile(0.06, 0.31, "full gait = two steps; the floor admits a legless body's fast bounce (~13 frames at 24 fps) — the 15% depth rule rejects the one-step half period when the near/far leg shows, and the gait floor (min_seconds) catches it when it does not", gait=True, min_seconds=0.6, window_seconds=(0.5, 1.6)),
    "run": LoopProfile(0.07, 0.23, "faster gait", gait=True, min_seconds=0.35, window_seconds=(0.3, 1.2)),
    "jump": LoopProfile(0.11, 0.45, "crouch-spring-land-return", one_shot_ok=True),
    "attack": LoopProfile(0.11, 0.45, "swing and return to ready; retain at least half a second of repeat context", one_shot_ok=True, action_seconds=2.5),
    "default": LoopProfile(0.10, 0.45, "generic in-place action", one_shot_ok=True),
}


def profile_for(state: str | None) -> LoopProfile:
    return STATE_PROFILES.get((state or "").strip().lower(), STATE_PROFILES["default"])


@dataclass(frozen=True)
class CutWindow:
    """The cut's length window, worked out once (`of`) and read by every search that sets a length.

    `lo`/`hi` are the first search's window: the state's, save where the caller set a bound
    (`min_len`/`max_len`, --min-len/--max-len). A search that looks elsewhere asks this for its own
    window — the gait fallback and the one-shot failover past the state's ceiling (`past`), a count of
    steps two lengths on (`within`), a window two steps long (`max_len`, local_cycle's `length_cap`) —
    and gets it inside the caller's bounds: an explicit bound is never widened, and no search sets one
    of its own. `hold` is the last word on any cut, whatever chose it."""
    lo: int
    hi: int
    min_len: int | None = None
    max_len: int | None = None

    @classmethod
    def of(cls, prof: LoopProfile, n: int, fps: float, min_len: int | None, max_len: int | None) -> "CutWindow":
        lo_default, hi_default = prof.window(n, fps)
        lo = min_len if min_len is not None else lo_default
        return cls(lo, max_len if max_len is not None else max(lo + 2, hi_default), min_len, max_len)

    def within(self, lo: int, hi: int) -> tuple[int, int]:
        """A search's own window [lo, hi] inside the caller's bounds (empty when lo > hi comes back)."""
        return (lo if self.min_len is None else max(lo, self.min_len),
                hi if self.max_len is None else min(hi, self.max_len))

    def past(self, hi: int) -> int:
        """The ceiling of a search past the state's window: `hi`, or the caller's own where it set one."""
        return hi if self.max_len is None else self.max_len

    def said(self) -> str:
        """The bounds the caller set, as given on the command line."""
        return " ".join(f"--{flag} {v}" for flag, v in (("min-len", self.min_len), ("max-len", self.max_len)) if v is not None)

    def hold(self, cycle: dict[str, Any]) -> None:
        """Raise when a cut is outside the caller's bounds: two explicit instructions that disagree are
        a failure, never one of them followed without a word."""
        length = cycle["length"]
        if (self.min_len is not None and length < self.min_len) or (self.max_len is not None and length > self.max_len):
            exc = ValueError(f"the cut is {length} frames long ({cycle.get('kind', 'cut')} from frame {cycle['start']}), outside {self.said()}")
            exc.diagnostics = {**cycle, "window_refused": {"min_len": self.min_len, "max_len": self.max_len}}  # type: ignore[attr-defined]
            raise exc


def _load_small(path: Path) -> np.ndarray:
    return _small_features(Image.open(path).convert("RGBA"))


def _small_features(image: Image.Image) -> np.ndarray:
    im = image.copy()
    im.thumbnail((ANALYSIS_SIZE, ANALYSIS_SIZE))
    a = np.asarray(im, dtype=np.float32) / 255.0
    rgb = a[..., :3] * a[..., 3:4]  # premultiplied: transparent pixels contribute 0
    return np.concatenate([rgb, a[..., 3:4]], axis=-1).reshape(-1)


def frame_masses(files: list[Path]) -> np.ndarray:
    """Per-frame pixel mass of the analysis thumbnail (mean |premultiplied rgba|): how much
    subject there is, on the same scale as the distance matrix."""
    return np.array([float(np.abs(_load_small(f)).mean()) for f in files], dtype=np.float32)


def leg_signals(frames: list[Image.Image]) -> dict[str, list[float]] | None:
    """The legs' per-frame signals for the two-cycle screen's record (`legs.strike_signals`), or
    None where a frame has no solid body to read them from."""
    try:
        return legs_mod.strike_signals(frames)
    except ValueError:
        return None


def distance_matrix(files: list[Path]) -> np.ndarray:
    return _distances(np.stack([_load_small(f) for f in files]))


def _distances(flat: np.ndarray) -> np.ndarray:
    """The distance between every two frames of their analysis features (`_small_features`)."""
    n = len(flat)
    D = np.zeros((n, n), dtype=np.float32)
    for i in range(n):
        D[i] = np.abs(flat - flat[i]).mean(axis=1)
    return D


def _repeat_context(D: np.ndarray, start: int, length: int, step: float) -> dict[str, Any]:
    """Compare a neighbourhood at the cut with the same poses one cycle later.

    A quarter-cycle on either side samples half a cycle of motion instead of one
    coincident pose. At a clip edge only real pairs participate; no padding or
    synthetic wrap is evidence of repetition. Normalise by the candidate's
    playback step so the cost is independent of character size and contrast.
    This measures temporal consistency, not limb identity.
    """
    radius = max(1, length // 4)
    first = max(0, start - radius)
    stop = min(len(D) - length, start + radius + 1)
    error = float(np.mean([D[j, j + length] for j in range(first, stop)]))
    return {
        "context_pair_range": [first, stop],  # half-open source indices
        "context_repeat_error": error,
        "context_repeat_over_step": error / step if step > 0 else math.inf,
    }


def detect_cycle(D: np.ndarray, *, min_len: int, max_len: int, gait_floor: int | None = None,
                 signals: dict[str, list[float]] | None = None) -> dict[str, Any]:
    """Global period, then a wrap-compatible start with coherent gait context.

    `gait_floor` (frames) turns on the half-period guard: a period below it is one step
    of a two-step gait, so the doubled period is taken when it repeats about as well
    (see GAIT_DOUBLE_TOL). Above the floor, ambiguous non-exact harmonics may also
    retain two phase occurrences; the report flags that decision for visual review.
    Gait starts balance the wrap step with observed repetition around the cut;
    other states keep their wrap-only ranking. The period taken is then screened for
    two or three cycles (`fundamental`, `period.screen`; `signals` are the frames'
    `legs.strike_signals`, for the record): what is found is recorded, nothing is
    cut shorter."""
    n = D.shape[0]
    max_len = min(max_len, n - 2)
    if min_len < 2 or max_len < min_len:
        raise SystemExit(f"video-loop: window [{min_len}, {max_len}] is empty for {n} frames")
    adjacent = np.array([D[i, i + 1] for i in range(n - 1)])
    prof: dict[int, float] = {}
    for L in range(max(2, min_len // 2), max_len + 1):
        prof[L] = float(np.mean([D[j, j + L] for j in range(0, n - L, 2)]))
    cands = [L for L in range(min_len, max_len + 1) if L - 1 in prof and L + 1 in prof and prof[L] <= prof[L - 1] and prof[L] <= prof[L + 1]]
    if not cands:
        cands = list(range(min_len, max_len + 1))
    # The true period is the SMALLEST minimum that is about as deep as the deepest one:
    # exact repeats also dip at 2x and 3x the period, and a half-period look-alike dips
    # noticeably less (near/far limb difference) — so a 15% depth tolerance separates both.
    deepest = min(prof[L] for L in cands)
    period = min(L for L in cands if prof[L] <= deepest * 1.15 + 1e-4)  # abs floor: exact repeats sit at ~0
    guard: dict[str, Any] = {"applied": False}
    if gait_floor is not None and period < gait_floor:
        # A period under the gait floor is one step, not a gait. The full gait is the
        # repeat at about twice that; the profile's own minimum near 2x (within
        # GAIT_DOUBLE_SEARCH) is the candidate, since a real cycle rarely lands on
        # exactly 2p. If no such repeat exists, the clip holds one step only — a
        # quadruped whose near and far legs read alike does this — and keeping the
        # step would loop half a stride without a word. Refuse instead, under the
        # same words as a flat profile, so a caller's regenerate-on-no-period rule
        # covers both.
        doubles = [L for L in cands if abs(L - 2 * period) <= GAIT_DOUBLE_SEARCH and L <= max_len]
        if not doubles:
            doubles = [L for L in (2 * period - 1, 2 * period, 2 * period + 1) if L in prof and L <= max_len]
        L2 = min(doubles, key=lambda L: prof[L]) if doubles else None
        if L2 is not None and prof[L2] <= prof[period] * (1 + GAIT_DOUBLE_TOL) + 1e-4:
            guard = {"applied": True, "from": period, "to": L2, "gait_floor": gait_floor, "depth_ratio": round(prof[L2] / prof[period], 3) if prof[period] > 0 else None}
            period = L2
        else:
            guard = {"applied": False, "below_floor": period, "gait_floor": gait_floor,
                     "double_candidate": L2, "double_depth_ratio": round(prof[L2] / prof[period], 3) if L2 is not None and prof[period] > 0 else None,
                     "why": "the only repeat is one step: nothing near twice the period repeats about as well"}
            exc = SystemExit(
                f"video-loop: no periodic cycle found — the only repeat is one step ({period} frames, under the gait floor of "
                f"{gait_floor}) and nothing near twice that ({2 * period - GAIT_DOUBLE_SEARCH}..{2 * period + GAIT_DOUBLE_SEARCH}) "
                f"repeats within {round(GAIT_DOUBLE_TOL * 100)} % of it"
                + (f" (best {L2}: {round(prof[L2] / prof[period], 2)}x worse)" if L2 is not None and prof[period] > 0 else "")
                + "; the clip shows a half stride, regenerate it"
            )
            exc.diagnostics = {"kind": "periodic", "period_global": period, "half_period_guard": guard,
                               "profile_minima": [[L, round(prof[L], 5)] for L in sorted(cands, key=lambda L: prof[L])[:6]]}
            raise exc
    # A plausible duration does not prove that a gait contains both phases. If a
    # second local minimum at twice the period is similarly good, retain both
    # occurrences at the original fps. This is a conservative ambiguity policy,
    # not an anatomical inference: a true short cycle may be shown twice.
    # Do it only once, inside the requested window, and leave near-exact repeats
    # alone. The duration-floor guard above still owns implausibly short beats.
    profile_mean = float(np.mean([prof[L] for L in prof]))
    review_recommended = False
    if gait_floor is not None and period >= gait_floor and not guard["applied"]:
        ordinary_step = float(adjacent.mean())
        repeat_fraction = prof[period] / ordinary_step if ordinary_step > 0 else math.inf
        doubles = [L for L in cands if abs(L - 2 * period) <= 1]
        if doubles and repeat_fraction > GAIT_NEAR_EXACT_STEP_FRACTION:
            L2 = min(doubles, key=lambda L: prof[L])
            if (prof[L2] <= prof[period] * (1 + GAIT_DOUBLE_TOL) + 1e-4
                    and profile_mean > 0
                    and (profile_mean - prof[L2]) / profile_mean >= PERIODICITY_MIN):
                guard = {
                    "applied": True, "from": period, "to": L2,
                    "gait_floor": gait_floor, "reason": "ambiguous-harmonic",
                    "depth_ratio": round(prof[L2] / prof[period], 3),
                    "repeat_error_over_step": round(repeat_fraction, 3),
                    "why": "both periods are plausible; retain two phase occurrences at source speed",
                }
                period = L2
                review_recommended = True
    periodicity = (profile_mean - prof[period]) / profile_mean if profile_mean > 0 else 0.0
    # A half or a third of the period that returns to a pose on the motion's path may be the
    # cycle, or one step of it with the legs alike: recorded, never taken (sprite_gen/video/period.py).
    fundamental = period_mod.screen(
        period, D=D, prof=prof, minima=period_mod.local_minima(prof), mean=profile_mean,
        lowest=max(min_len, gait_floor or 0), periodicity_min=PERIODICITY_MIN, signals=signals, gait=gait_floor is not None,
        floor_why="the gait floor" if gait_floor is not None and gait_floor >= min_len else "the window")
    # Score the last displayed frame -> first frame transition against an ordinary
    # playback step. Minimising distance alone rewards a repeated pose (a stall).
    # Log distance penalises steps that are too short or too long symmetrically.
    best: dict[str, Any] | None = None
    best_score = math.inf
    candidates = []
    for L in (period - 1, period, period + 1):
        if L < min_len or L > max_len:
            continue
        for i in range(0, n - L):
            seam = float(D[i + L - 1, i])
            inner = float(adjacent[i : i + L - 1].mean())
            ratio = seam / inner if inner > 0 else math.inf
            score = abs(math.log(ratio)) if ratio > 0 else math.inf
            candidates.append({"start": i, "length": L, "seam": seam, "inner_mean_adjacent": inner, "ratio": ratio})
            selection = None
            if gait_floor is not None:
                selection = _repeat_context(D, i, L, inner)
                selection["method"] = "repeat-context-and-wrap"
                selection["wrap_log_error"] = score
                score += selection["context_repeat_over_step"]
                selection["score"] = score
            if best is None or score < best_score:
                best_score = score
                best = {"start": i, "length": L, "seam": seam, "inner_mean_adjacent": inner,
                        "ratio": ratio,
                        "next_frame_distance": float(D[i, i + L]) if i + L < n else None}
                if selection is not None:
                    best["selection"] = selection
    assert best is not None
    best["candidates"] = candidates
    best["repeat_pairs"] = n - period
    best["profile_sample_pairs"] = len(range(0, n - period, 2))
    best["period_global"] = period
    best["half_period_guard"] = guard
    best["fundamental"] = fundamental
    best["review_recommended"] = review_recommended
    best["periodicity"] = round(periodicity, 4)  # how far below the profile mean the period dips (0 = flat = no period)
    best["profile_minima"] = [[L, round(prof[L], 5)] for L in sorted(cands, key=lambda L: prof[L])[:6]]
    return best


class CycleSelectionError(SystemExit):
    """A selection refusal with measurements that survive into the failure report."""

    def __init__(self, message: str, diagnostics: dict[str, Any]):
        super().__init__(message)
        self.diagnostics = diagnostics


def periodicity_floor(n: int, period: int, *, partial_repeat: bool) -> float:
    """Require stronger evidence when fewer than one full period can be compared.

    Full-cycle coverage keeps the existing 15% floor. Missing coverage increases
    the required dip linearly toward 100%; one or two lucky pairs cannot prove
    a repeat. This is a conservative coverage policy, not a confidence interval.
    """
    coverage = min(1.0, max(0, n - period) / period)
    return PERIODICITY_MIN + (1 - PERIODICITY_MIN) * (1 - coverage) if partial_repeat else PERIODICITY_MIN


def detect_one_shot(D: np.ndarray, *, min_len: int, max_len: int, frame_mass: np.ndarray | None = None) -> dict[str, Any]:
    """Find an observed return pair enclosing a complete excursion.

    A global medoid can be the held strike instead of ready. Enumerate close
    endpoint poses, measure departure from both, and require the peak's entire
    active component to have observed rest on BOTH sides. A clipped component
    at frame zero or n-1 is never repaired by padding. The existing contrast /
    moved-mass floors still reject stand jitter; return distance must additionally
    be at most a quarter of the departure. No seam threshold is relaxed.
    No cut is shorter than `min_len` (nor ONE_SHOT_MIN_LEN) or longer than `max_len`; `run_loop`
    passes ONE_SHOT_MIN_LEN unless the caller set --min-len (`CutWindow`).
    """
    n = len(D)
    adjacent = np.diag(D, 1)
    candidates = []
    max_moved = 0.0
    shortest = max(ONE_SHOT_MIN_LEN, min_len)
    for start in range(n - ONE_SHOT_MIN_LEN + 1):
        for end in range(start + shortest - 1, min(n, start + max_len)):
            seam = float(D[start, end])
            e = (D[start] + D[end]) / 2
            peak_at = start + int(np.argmax(e[start:end + 1]))
            peak = float(e[peak_at])
            departure = peak - seam / 2
            if departure <= 0 or seam > departure * 0.25:
                continue
            med = float(np.median(e))
            mad = float(np.median(np.abs(e - med))) or 1e-6
            contrast = (peak - med) / mad
            mass = float((frame_mass[start] + frame_mass[end]) / 2) if frame_mass is not None else 0
            moved = departure / mass if mass > 0 else None
            max_moved = max(max_moved, moved or 0)
            if contrast >= ONE_SHOT_MIN_CONTRAST:
                rule = "contrast"
                active = e > med + ONE_SHOT_MIN_CONTRAST * mad
            elif moved is not None and moved >= ONE_SHOT_MIN_MOVED:
                rule = "moved"
                active = e > seam / 2 + 0.5 * departure
            else:
                continue
            if not active[peak_at]:
                continue
            a = b = peak_at
            while a > 0 and active[a - 1]:
                a -= 1
            while b + 1 < n and active[b + 1]:
                b += 1
            if b - a + 1 < ONE_SHOT_MIN_ACTIVE:
                continue
            if not (start <= a - ONE_SHOT_PAD and end >= b + ONE_SHOT_PAD):
                continue
            inner = float(adjacent[start:end].mean())
            if inner <= 0 or departure < ONE_SHOT_MIN_COHERENCE * inner:
                continue
            candidates.append({
                "excursion_over_step": departure / inner,
                "kind": "one-shot", "start": start, "length": end - start + 1,
                "seam": seam, "inner_mean_adjacent": inner,
                "ratio": seam / inner if inner > 0 else math.inf,
                "period_global": None, "periodicity": None,
                "rest_frame": start, "return_pair": [start, end],
                "return_distance_over_departure": seam / departure,
                "excursion": [a, b], "excursion_peak": peak_at,
                "excursion_contrast": round(contrast, 2),
                "excursion_moved": round(moved, 3) if moved is not None else None,
                "excursion_rule": rule, "departure": departure,
            })
    if not candidates:
        raise CycleSelectionError(
            f"video-loop: no complete one-shot return — the clip never leaves its rest pose "
            f"and returns with observed endpoints (moved {max_moved:.2f}, "
            f"need {ONE_SHOT_MIN_MOVED})",
            {"kind": "one-shot", "candidates": []},
        )
    # Keep the full strongest action, then minimise excess rest. Do not choose a
    # tiny low-seam twitch just because its endpoints happen to match exactly.
    strongest = max(c["departure"] for c in candidates)
    eligible = [c for c in candidates if c["departure"] >= strongest * 0.95]
    best = min(eligible, key=lambda c: (c["length"], c["ratio"], c["start"]))
    return {**best, "candidates": candidates}


def fixed_cycle(D: np.ndarray, *, start: int, length: int) -> dict[str, Any]:
    """An explicitly requested cut (`--cycle fixed --start N --length L`): no detection, no
    periodicity gate — the caller says which frames are the cycle and the report says so
    (kind = "fixed"). The seam is still measured and the seam gate still applies."""
    n = D.shape[0]
    if start < 0 or length < 2 or start + length > n:
        raise SystemExit(f"video-loop: --start {start} --length {length} does not fit {n} frames")
    end = start + length - 1
    adjacent = np.array([D[i, i + 1] for i in range(start, end)])
    inner = float(adjacent.mean())
    seam = float(D[start, end])
    return {"kind": "fixed", "start": start, "length": length, "seam": seam, "inner_mean_adjacent": inner,
            "ratio": seam / inner if inner > 0 else math.inf, "period_global": None, "periodicity": None}


def pinned_cycle(D: np.ndarray, *, seam_max: float) -> dict[str, Any]:
    """The whole clip as one cycle, for a clip pinned to end on its first frame.

    Every frame but the last is kept: the last re-renders the first, so playing it too would show
    that pose twice at the wrap. The wrap (second-to-last -> first) then plays like the step into
    that last frame, and closes when the last frame really is the first again — so the gate is
    the pin error, allowed the same `seam_max` steps as any seam or the re-render noise, whichever
    is larger. A near-still clip moves so little per frame that the seam ratio alone reads its
    re-render noise as a jump.
    """
    n = D.shape[0]
    length = n - 1
    adjacent = np.array([D[i, i + 1] for i in range(length - 1)])
    inner = float(adjacent.mean())
    seam = float(D[length - 1, 0])
    pin_error = float(D[n - 1, 0])
    return {"kind": "pinned", "start": 0, "length": length, "seam": seam, "inner_mean_adjacent": inner,
            "ratio": seam / inner if inner > 0 else math.inf, "pin_error": pin_error,
            "pin_tolerance": max(seam_max * inner, PIN_NOISE_MAX), "period_global": None, "periodicity": None}


def _scrub(image: Image.Image) -> int:
    px = image.load()
    n = 0
    for y in range(image.height):
        for x in range(image.width):
            r, g, b, a = px[x, y]
            if a == 0 and (r or g or b):
                px[x, y] = (0, 0, 0, 0)
                n += 1
    return n


def foot_centre(image: Image.Image, box: tuple[int, int, int, int]) -> float:
    """Mean x of the opaque pixels in the lowest FOOT_BAND of the subject's own bbox —
    the ground-contact line, which is what a placed sprite is judged by."""
    a = np.asarray(image.getchannel("A"))
    band = max(1, round((box[3] - box[1]) * FOOT_BAND))
    rows = a[box[3] - band : box[3], box[0] : box[2]]
    ys, xs = np.nonzero(rows >= 8)
    if xs.size == 0:
        return (box[0] + box[2]) / 2
    return float(box[0] + xs.mean())


def body_centre(image: Image.Image, box: tuple[int, int, int, int]) -> float:
    """Mean x of every opaque pixel — the whole body's mass, which a gait swings far less
    than it swings the foot line."""
    a = np.asarray(image.getchannel("A"))[box[1] : box[3], box[0] : box[2]]
    xs = np.nonzero(a >= 8)[1]
    return float(box[0] + xs.mean()) if xs.size else (box[0] + box[2]) / 2


def drift_reference(frames: list[Image.Image], boxes: list[tuple[int, int, int, int]]) -> tuple[list[float], float, float]:
    """Per-frame alignment reference for `--anchor feet`.

    Drift is a slow translation; a gait is periodic. The cycle holds whole periods, so a
    straight line fitted to the body's centre across it carries the drift and not the
    step. Only that line is removed: the reference is the mean foot line riding the
    drift. Pinning each frame's own foot line instead pins the planted foot — which
    changes every step — and makes a body that stood still lurch by the stride.
    Returns (reference x per frame, drift removed in px, foot-line sway in px)."""
    feet = np.array([foot_centre(im, b) for im, b in zip(frames, boxes)])
    centres = np.array([body_centre(im, b) for im, b in zip(frames, boxes)])
    t = np.arange(len(frames), dtype=float)
    slope = float(np.polyfit(t, centres, 1)[0]) if len(frames) > 1 else 0.0
    trend = slope * t
    ref = float(np.mean(feet - trend)) + trend
    return [float(r) for r in ref], abs(slope * (len(frames) - 1)), float(np.ptp(feet - trend))


def body_wrap_offset(frames: list[Image.Image], *, band: float = BODY_ANCHOR_BAND, search: int = BODY_ANCHOR_SEARCH) -> int:
    """Horizontal offset (px) that best lays the LAST frame's head and torso over the FIRST's.

    A gait clip drifts a few pixels over one cycle, and the last-to-first wrap shows that
    drift as a sideways jump. The legs are mid-stride and the tail mid-swing at both ends,
    so they cannot say where the body is; the top of the first frame's box (head, torso,
    `band` of its height) can. Whole-pixel registration over that region, over a small
    horizontal search, is the one measurement `--anchor body` makes — it is then spread
    as a ramp across the cycle, never applied frame by frame (per-frame fitting turns a
    head bob into a full-body shiver, measured 2026-09-22)."""
    if len(frames) < 2:
        return 0
    first = np.asarray(frames[0], dtype=np.float32)
    last = np.asarray(frames[-1], dtype=np.float32)
    alpha = first[:, :, 3] >= 8
    rows = np.where(alpha.any(axis=1))[0]
    cols = np.where(alpha.any(axis=0))[0]
    if len(rows) == 0 or len(cols) == 0:
        return 0
    top, bottom, left, right = rows[0], rows[-1], cols[0], cols[-1]
    mask = np.zeros_like(alpha)
    mask[top : top + max(1, int((bottom - top) * band)), left : right + 1] = True
    ref = first[mask]

    def cost(dx: int) -> float:
        return float(np.abs(ref - np.roll(last, dx, axis=1)[mask]).mean())

    return min(range(-search, search + 1), key=cost)


def ramp_frames(frames: list[Image.Image], wrap_dx: int) -> list[Image.Image]:
    """Shift frame k by round(wrap_dx * k / L) so the cycle's end returns to its start."""
    L = len(frames)
    if wrap_dx == 0 or L < 2:
        return frames
    out = []
    for k, im in enumerate(frames):
        dx = int(round(wrap_dx * k / L))
        if dx == 0:
            out.append(im)
            continue
        shifted = Image.new("RGBA", im.size, (0, 0, 0, 0))
        shifted.paste(im, (dx, 0))
        out.append(shifted)
    return out


def standing_height(path: Path, frame: int = 0) -> int:
    """The subject's height in clip frame `frame`: the clip's first frame, the base still's pose as filmed.

    Every clip starts from its still (image-to-video), so this is the same pose in every
    state of one character — which is what one `--body-height` across states has to measure
    to give that character one size. A walk or run whose cut is filmed at another size than the
    clip's first frame is read on the cut's first frame instead (run_loop).
    """
    box = Image.open(path).convert("RGBA").getchannel("A").point(lambda v: 255 if v >= 8 else 0).getbbox()
    if box is None:
        which = "the clip's first frame" if frame == 0 else f"frame {frame}, the cut's first"
        raise SystemExit(f"video-loop: {path.name}, {which}, has no subject to measure the standing height on (--body-height)")
    return box[3] - box[1]


def build_strip(frames: list[Image.Image], *, max_cells: int = STRIP_MAX_CELLS, max_height: int = STRIP_MAX_HEIGHT, max_width: int = STRIP_MAX_WIDTH, cycle_seconds: float, body_height: int | None = None, anchor: str = "none", kind: str = "periodic", standing_src: int | None = None, standing_frame: int = 0) -> tuple[Image.Image, dict[str, Any]]:
    """Union-crop (no bottom pad so feet meet the floor), scale, bottom-align, tile horizontally.

    The cell count is capped by the strip's PIXEL width (`max_width`) as well as by
    `max_cells`: the crop is measured over every cycle frame first, then as many evenly
    spaced frames as fit are kept. Subsampling is recorded in the meta, never silent."""
    L = len(frames)
    boxes = [im.getchannel("A").point(lambda v: 255 if v >= 8 else 0).getbbox() for im in frames]
    boxes = [b for b in boxes if b]
    if not boxes:
        raise SystemExit("video-loop: every cycle frame is fully transparent")
    # The side margins may reach past the frame: a subject allowed to touch the left or right
    # edge (video-frames --allow-subject-edge-contact) still gets its 8 transparent columns,
    # so no cell corner is ever the subject. `crop` fills outside the frame with alpha 0.
    left = min(b[0] for b in boxes) - 8
    top = max(0, min(b[1] for b in boxes) - 8)
    right = max(b[2] for b in boxes) + 8
    bottom = max(b[3] for b in boxes)
    # body_h = the STANDING height: the tallest frame whose feet touch the floor. A median
    # over the whole cycle undercounts a jump (crouch + airborne frames dominate) and then
    # over-scales it — the 2026-09-09 hero read 22 % taller than the walk beside it.
    floor = max(b[3] for b in boxes)
    grounded = [b[3] - b[1] for b in boxes if b[3] >= floor - 4] or [b[3] - b[1] for b in boxes]
    # `standing_src` is the caller's own measurement of the standing pose (run_loop: the clip's
    # first frame, or the cut's first — clip frame `standing_frame` — where the cut is filmed at
    # another size than it). The tallest grounded frame counts whatever is raised overhead — an attack's
    # windup lifts the weapon above the head — and would shrink that state against the others.
    body_src = standing_src if standing_src is not None else max(grounded)
    # max_height is a ceiling on the CELL; an explicit body_height is a target for the BODY.
    # Without one, nothing is ever scaled up. With one, a state whose source body is SHORTER
    # than the request has to grow — clamping to 1.0 first made the option a downward clamp
    # only, so "the same value across states gives the same character size" was false for
    # exactly the states that needed it: a 200 px source and a 400 px source both asked for
    # 300 came out 200 and 300 (measured 2026-09-10). The cap still wins over the target.
    fit = max_height / (bottom - top)
    scale = min(1.0, fit) if body_height is None else min(fit, body_height / body_src)
    # --anchor feet: the model may have walked the subject across an "in-place" canvas;
    # a union crop keeps that drift inside every cell. Remove the drift (see
    # drift_reference) so every cell stands on the same mean foot line, and report it.
    feet, drift, sway = drift_reference(frames, boxes) if anchor == "feet" else (None, 0.0, 0.0)
    drift_px = round(drift)
    if feet:
        lead = max(fc - b[0] for fc, b in zip(feet, boxes)) + 8
        trail = max(b[2] - fc for fc, b in zip(feet, boxes)) + 8
        cell_src_w = lead + trail
    else:
        cell_src_w = right - left
    w = round(cell_src_w * scale)
    h = round((bottom - top) * scale)
    cap = max(1, min(max_cells, max_width // max(1, w)))
    idx = list(range(L))
    if L > cap:
        idx = [round(k * L / cap) for k in range(cap)]
    chosen = [frames[i] for i in idx]
    if feet:
        cells = []
        for i in idx:
            im = frames[i]
            cell = Image.new("RGBA", (round(cell_src_w), bottom - top), (0, 0, 0, 0))
            cell.alpha_composite(im.crop((0, top, im.width, bottom)), (round(lead - feet[i]), 0))
            cells.append(resize_cell(cell, (w, h)))
    else:
        cells = [resize_cell(im.crop((left, top, right, bottom)), (w, h)) for im in chosen]
    strip = Image.new("RGBA", (w * len(cells), h), (0, 0, 0, 0))
    for k, im in enumerate(cells):
        strip.alpha_composite(im, (k * w, 0))
    meta = {
        "frames": len(cells),
        "sample_indices": idx,
        "source_rect": [left, top, right, bottom] if not feet else None,
        "w": w,
        "h": h,
        # how the cycle was cut, and whether a runtime should repeat it: a one-shot
        # (rest -> action -> rest) plays once on a trigger; every other cut is a loop.
        # The spec asset loader reads `loop` from this sidecar.
        "kind": kind,
        "loop": kind != "one-shot",
        "body_h": round(body_src * scale),
        "body_src_h": body_src,  # the standing height as filmed; body_h / body_src_h > 1 means the cells were upscaled
        "body_ref": ("cut-first-frame" if standing_frame else "first-frame") if standing_src is not None else "tallest-grounded",
        "scale": round(scale, 4),
        "delay_ms": round(1000 * cycle_seconds / len(cells), 2),
        "cycle_frames": L,
        "cycle_seconds": round(cycle_seconds, 4),
        "subsampled": L > cap,
        "cell_cap": cap,
        "top_margin_px": top,
        "cell_height_cap": max_height,  # --strip-height: what a rebuild of these cells (video-cycle-align) scales against
        "body_height_target": body_height,
        "foot_anchor": anchor,  # "none" | "feet" — how the cells were aligned
        "drift_px": drift_px,  # source px of slow in-canvas drift removed across the cycle (0 when not measured)
        "foot_sway_px": round(sway),  # source px the planted foot moves within the gait, kept as is (0 when not measured)
        "foot_x": round(lead * scale) if feet else None,  # x of the foot line inside every cell
    }
    if standing_src is not None and standing_frame:
        meta["body_ref_frame"] = standing_frame  # the clip frame the standing height was read on
    if feet:
        # the spec asset loader reads a sidecar `anchor` as the [x, y] pivot (default:
        # bottom-centre); with feet alignment the true pivot is the foot line at the
        # cell bottom, so declare it and scenes stand the sprite on its feet
        meta["anchor"] = [meta["foot_x"], h]
    return strip, meta


def img2webp_supports_exact(binary: str | None = None) -> bool:
    """libwebp added `-exact` to img2webp in 1.5.0 (checked against the 1.4.0 and 1.5.0 release
    binaries, 2026-09-09); older builds (Ubuntu 24.04: 1.3.x) reject the flag with "Unknown option"
    and would rewrite RGB under alpha 0. Detected from `-h`, never assumed."""
    binary = binary or shutil.which("img2webp")
    if not binary:
        return False
    try:
        proc = subprocess.run([binary, "-h"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return "-exact" in (proc.stdout + proc.stderr)


def write_webp(frames: list[Image.Image], out: Path, *, delay_ms: int, workdir: Path) -> None:
    """Animated WebP through libwebp's img2webp with -exact (Pillow's animated writer drops `exact`
    and rewrites RGB under alpha 0 to white; measured 2026-09-08)."""
    img2webp = shutil.which("img2webp")
    if not img2webp:
        raise SystemExit("video-loop: `img2webp` not found on PATH — install libwebp (brew install webp) for exact-alpha WebP")
    if not img2webp_supports_exact(img2webp):
        raise SystemExit(
            "video-loop: this img2webp has no `-exact` option (libwebp < 1.5; Ubuntu 24.04 ships 1.3.x) — "
            "install libwebp >= 1.5 (brew install webp, or the official binaries from storage.googleapis.com/downloads.webmproject.org)"
        )
    workdir.mkdir(parents=True, exist_ok=True)
    paths = []
    for k, im in enumerate(frames):
        p = workdir / f"webp-{k:03d}.png"
        im.save(p)
        paths.append(str(p))
    proc = subprocess.run([img2webp, "-loop", "0", "-lossless", "-exact", "-d", str(delay_ms), *paths, "-o", str(out)], capture_output=True, text=True)
    if proc.returncode != 0 or not out.is_file():
        raise SystemExit(f"video-loop: img2webp failed: {proc.stderr.strip()[:300]}")


def verify_animation(path: Path, *, expect_frames: int, check_stale: bool) -> dict[str, Any]:
    # Closed on the way out: `video-follow` checks its animations before it moves them over the loop's.
    with Image.open(path) as im:
        n = getattr(im, "n_frames", 1)
        loop = im.info.get("loop")
        corners_ok = True
        stale = 0
        for k in range(n):
            im.seek(k)
            f = im.convert("RGBA")
            w, h = f.size
            corners_ok &= all(f.getpixel(c)[3] == 0 for c in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)))
            if check_stale:
                stale += sum(1 for p in f.get_flattened_data() if p[3] == 0 and (p[0] or p[1] or p[2]))
        report = {"file": path.name, "format": im.format, "n_frames": n, "loop": loop, "size": list(im.size), "corners_transparent": corners_ok, "stale_rgb_under_alpha0": stale, "bytes": path.stat().st_size}
    problems = []
    if n != expect_frames:
        problems.append(f"{n} frames, expected {expect_frames}")
    if loop != 0:
        problems.append(f"loop={loop!r}, expected 0 (infinite)")
    if not corners_ok:
        problems.append("a corner is not transparent")
    if stale:
        problems.append(f"{stale} transparent pixels carry RGB")
    if problems:
        raise SystemExit(f"video-loop: {path.name} failed verification: {'; '.join(problems)}")
    return report


def write_loop_report(target: Path, payload: dict[str, Any]) -> None:
    """Strict JSON, including refusals with undefined (zero-motion) ratios."""
    def finite(value: Any) -> Any:
        if isinstance(value, float) and not math.isfinite(value):
            return None
        if isinstance(value, dict):
            return {key: finite(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [finite(item) for item in value]
        return value

    target.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(target, json.dumps(finite(payload), ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def resampled_cells(strip: Image.Image, meta: dict[str, Any], idx: list[int], length: int) -> list[Image.Image]:
    """The cells of `strip` (`build_strip`, its `meta`) at the frames `idx` of a cycle `length` frames long: the
    GIF and WebP frames, and what the seam gate reads on rendered cells. A strip subsampled past its cell cap
    holds fewer cells than the cycle has frames, and gives the nearest."""
    cells = [strip.crop((k * meta["w"], 0, (k + 1) * meta["w"], meta["h"])) for k in range(meta["frames"])]
    return [cells[min(len(cells) - 1, round(j * len(cells) / length))] for j in idx]


def shown_runs(cells: list[Image.Image]) -> int:
    """The frames a GIF or WebP of `cells` holds: a cell shown twice in a row (a filmed ghost given way
    to the frame beside it, `--between nearest` stretching a loop) is one frame of twice the delay in
    both, so one per run of identical cells."""
    return 1 + sum(1 for a, b in zip(cells, cells[1:]) if a.tobytes() != b.tobytes())


def _repair_jumps(frames: list[Image.Image], interpolate: rife_mod.Interpolate | None, *, facing: str,
                  required: bool, screen: dict[str, Any]) -> tuple[list[Image.Image], dict[str, Any]]:
    """`repair_mod.repair_jumps` on the cut as filmed and its ghost `screen`, with RIFE located only
    once a frame is to be made: a loop without a jump or a ghost between two clean frames needs no
    binary. The report names the interpolator that made the frames.

    A frame to make and no RIFE installed: `required` lets `RifeNotInstalled` through; otherwise
    each filmed ghost gives way to the clean frame beside it, a jump stays as filmed, and the record
    says why where a jump was left (`rife`, `install`; `applied` false where nothing was replaced)."""
    made_by: list[dict[str, str]] = []
    calls = 0

    def lazy(a: Image.Image, b: Image.Image, t: float) -> Image.Image:
        nonlocal interpolate, calls
        if interpolate is None:
            located = rife_mod.Rife()
            made_by.append(located.describe())
            interpolate = located
        calls += 1
        return interpolate(a, b, t)

    try:
        repaired, record = repair_mod.repair_jumps(frames, lazy, facing=facing, screen=screen)
    except rife_mod.RifeNotInstalled as exc:
        if required:
            raise
        # RIFE is located before the first frame is made, so nothing was made yet: the stage runs again
        # with no interpolator, each ghost giving way to the clean frame beside it and a jump left as filmed.
        repaired, record = repair_mod.repair_jumps(frames, None, facing=facing, screen=screen)
        record["applied"] = bool(record["replaced"])
        if "unmade" in record:
            record.update(why="RIFE not installed — cut as filmed" if not record["replaced"] else
                          "RIFE not installed — the jump cut as filmed, each filmed ghost given way to the clean frame beside it",
                          rife=str(exc), install=rife_mod.INSTALL_COMMAND)
        return repaired, record
    frames = repaired
    record["applied"] = bool(record["replaced"])
    if made_by:
        record["interpolator"] = {"kind": "rife-ncnn-vulkan", **made_by[0]}
    elif calls:
        record["interpolator"] = {"kind": "injected"}
    return frames, record


def _ghost_lines(jump_repair: dict[str, Any]) -> list[str]:
    """What became of each filmed ghost the jump repair stage read, in words (`video-loop: warning:` lines)."""
    lines = []
    for r in jump_repair.get("rounds", []):
        if r.get("why") != "ghost":
            continue
        j = r["target"]
        line = (f"frame {j} of the cut carries a part-covered band over {100 * r['original']['ghost']:.2f} % of its body, at least "
                f"{rife_mod.GHOST_THICK} px thick — a filmed ghost; ")
        if r["taken"] == "rife":
            lines.append(line + f"given way to RIFE's frame between frames {r['neighbours'][0]} and {r['neighbours'][1]} "
                         f"(cycle/frame-{j:03d}.png) (docs/loop-repair.md section 2)")
            continue
        if r["taken"] is None:
            lines.append(line + f"and so are the frames beside it ({r['neighbours'][0]} and {r['neighbours'][1]}); kept, as there "
                         f"is no clean frame to give way to (cycle/frame-{j:03d}.png) — film this direction again (docs/loop-repair.md section 2)")
            continue
        if r["proposal"] is not None:
            why = f"RIFE's frame between its neighbours has a fault ({', '.join(r['faults'])})"
        elif r["no_proposal"] == "no interpolator":
            why = f"RIFE is not installed, so no frame between its neighbours was made (`{rife_mod.INSTALL_COMMAND}`)"
        else:
            why = r["no_proposal"]
        lines.append(line + f"given way to frame {r['taken']['source']} beside it, shown twice in a row (cycle/frame-{j:03d}.png): "
                     f"{why} (docs/loop-repair.md section 2)")
    return lines


def moved_alpha(frames: list[Image.Image], analysis: dict[str, Any]) -> list[np.ndarray]:
    """The alpha of every frame, each moved by the analysis translation `auto_motion.analyse` measured
    (its drift taken out, the way the cut will be corrected), cropped once to the clip's subject:
    what `wrap_pop_on` and `HeldEdge` read a cut on."""
    shifts = np.rint(np.asarray(analysis["analysis_only_translation_xy"], dtype=np.float64)).astype(int)
    pad = int(np.abs(shifts).max()) + 1
    boxes = [f.getchannel("A").point(lambda v: 255 if v >= repair_mod.ALPHA_SOLID else 0).getbbox() for f in frames]
    boxes = [b for b in boxes if b]
    box = (min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes))
    w, h = box[2] - box[0] + 2 * pad, box[3] - box[1] + 2 * pad
    moved = []
    for f, (dx, dy) in zip(frames, shifts):
        a = np.zeros((h, w), dtype=np.uint8)
        crop = np.asarray(f.getchannel("A").crop(box))
        a[pad + dy:pad + dy + crop.shape[0], pad + dx:pad + dx + crop.shape[1]] = crop
        moved.append(a)
    return moved


def wrap_pop_on(moved: list[np.ndarray]) -> Any:
    """`repair.seam_pop` of a cut (start, length) of the moved alpha (`moved_alpha`): the top band's
    jump at the wrap, for `local_cycle.detect` to rank its candidates by. A cut's value is kept once
    measured."""
    measured: dict[tuple[int, int], dict[str, Any]] = {}

    def pop(start: int, length: int) -> dict[str, Any]:
        if (start, length) not in measured:
            try:
                measured[start, length] = repair_mod.seam_pop([a.astype(np.float32) / 255.0 for a in moved[start:start + length]])
            except ValueError as exc:
                # A frame with nothing in the top band: no jump read, and no pop to rank it by —
                # `local_cycle` neither takes it as closing nor as popping (`skipped`, why).
                measured[start, length] = {"skipped": str(exc), "reference": repair_mod.SEAM_POP_REFERENCE}
        return measured[start, length]
    return pop


class HeldEdge:
    """The held side of the moved alpha (`moved_alpha`), read by `local_cycle` only once a cut's top
    band pops: `side` of a cut (`repair.held_side`, or `skipped`) and `seam` of a cut on a side
    (`repair.held_edge`, or `skipped` with why). A side's edges are read once, on first use."""

    reference = repair_mod.HELD_EDGE_REFERENCE

    def __init__(self, moved: list[np.ndarray]):
        self.moved = moved
        self.frames = len(moved)
        self._edges: dict[str, np.ndarray] = {}

    def _masks(self, start: int, stop: int) -> list[np.ndarray]:
        return [a >= repair_mod.HELD_EDGE_ALPHA for a in self.moved[start:stop]]

    def side(self, start: int, length: int) -> dict[str, Any]:
        try:
            return {"side": repair_mod.held_side(self._masks(start, start + length))}
        except ValueError as exc:
            return {"skipped": str(exc)}

    def seam(self, start: int, length: int, side: str) -> dict[str, Any]:
        if side not in self._edges:
            self._edges[side] = repair_mod.side_edges(self._masks(0, self.frames), side)
        try:
            return repair_mod.held_edge(self._edges[side], start, length)
        except ValueError as exc:
            return {"skipped": str(exc), "reference": repair_mod.HELD_EDGE_REFERENCE}


def _counted(cycle: dict[str, Any], steps: int, *, window: CutWindow, D: np.ndarray, trajectory: np.ndarray,
             frames: list[Image.Image], moved: list[np.ndarray], detect: dict[str, Any]) -> dict[str, Any]:
    """The cut once its steps are counted (`--steps`): 2 keeps it; 1 cuts again in the window two of
    its lengths long, [2L-1, 2L+1], inside the caller's bounds (`window.within`) — not half the clip —
    with the same search (a repeat seen in the clip, the top band and the held side read again) save that
    the cut whose wrap the clip itself plays is taken among the equivalent ones (`local_cycle._closure`),
    and no window twice that. Where the caller's bounds leave none of [2L-1, 2L+1], the count and the
    bounds disagree: a failure, neither followed. Where they leave part of it, that part is read
    (`steps.window`, beside `steps.counted_window`). A clip too short to see such a window repeat is cut
    all the same, the count standing for the repeat (`local_cycle.counted`, `unseen` says why);
    `cycle.coverage` and the seam gate say the rest. Recorded `steps` (`first_cut`: the cut counted)."""
    first = {"start": cycle["start"], "length": cycle["length"]}
    if steps == 2:
        cycle["steps"] = {"count": 2, "by": "given", "given": 2}
        return cycle
    counted_window = [2 * first["length"] - 1, 2 * first["length"] + 1]
    lo, hi = window.within(*counted_window)
    record = {"count": 2, "by": "given", "given": 1, "first_cut": first, "window": [lo, hi]}
    if [lo, hi] != counted_window:
        record["counted_window"] = counted_window
    if lo > hi:
        exc = ValueError(f"--steps 1: the cut of {first['length']} frames from {first['start']} is one step, so the cycle is "
                         f"{counted_window[0]}-{counted_window[1]} frames long, and {window.said()} leaves none of that: the count "
                         f"and the window disagree — drop one, or give a window that holds the cycle")
        exc.diagnostics = {**cycle, "steps": {**record, "window": None, "refused": f"outside {window.said()}"}}  # type: ignore[attr-defined]
        raise exc
    signals = leg_signals(frames)
    try:
        found = local_cycle.detect(D, trajectory, min_len=lo, max_len=hi, length_cap=hi, signals=signals,
                                   wrap_pop=wrap_pop_on(moved), held_edge=HeldEdge(moved), double=False, closure=True, **detect)
    except ValueError as unseen:
        # Too short a clip to see the cycle repeat: the count stands for it (`cycle.coverage` says how short).
        try:
            found = local_cycle.counted(D, trajectory, min_len=lo, max_len=hi, periodicity_min=detect["periodicity_min"], signals=signals)
        except ValueError as exc:
            failed = ValueError(f"--steps 1: the cut of {first['length']} frames from {first['start']} is one step, and the clip "
                                f"({len(D)} frames) has no window {lo}-{hi} frames long to cut: {exc}")
            failed.diagnostics = {**getattr(unseen, "diagnostics", {}), "steps": record}  # type: ignore[attr-defined]
            raise failed from exc
        found["unseen"] = str(unseen)
    found["steps"] = record
    return found


def _from_lead_in(record: Any, lead: int) -> Any:
    """A search's record (a cut, or the windows a refusal measured) in the clip's own frame numbers: the
    search read the clip after its first `lead` frames, so every `start` and `context_pair_range` it wrote
    moves on by `lead`. A caller cuts again from these (`--cycle fixed --start`) on the whole clip."""
    if isinstance(record, dict):
        return {key: (value + lead if key == "start" and isinstance(value, int)
                      else [value[0] + lead, value[1] + lead] if key == "context_pair_range"
                      else _from_lead_in(value, lead)) for key, value in record.items()}
    if isinstance(record, list):
        return [_from_lead_in(value, lead) for value in record]
    return record


def _one_shot(D: np.ndarray, window: CutWindow, hi: int, masses: np.ndarray) -> dict[str, Any]:
    """`detect_one_shot` in its window: ONE_SHOT_MIN_LEN to `hi`, inside the caller's bounds. Where the
    caller set one and no one-shot fits, the refusal says the window it searched."""
    shortest, longest = window.within(ONE_SHOT_MIN_LEN, hi)
    try:
        return detect_one_shot(D, min_len=shortest, max_len=longest, frame_mass=masses)
    except CycleSelectionError as exc:
        if not window.said():
            raise
        raise CycleSelectionError(f"{exc} — in {shortest}-{longest} frames, inside {window.said()}", exc.diagnostics) from exc


def coverage_verdict(cycle: dict[str, Any]) -> list[str]:
    """A cut two steps long whose clip holds under COVERAGE_MIN of a cycle past it, in words; empty
    otherwise (and for a cut whose steps are not known)."""
    if "steps" not in cycle or cycle["coverage"] >= COVERAGE_MIN:
        return []
    return [f"the cut is two steps long ({cycle['length']} frames, one cycle) and the clip holds {cycle['coverage']:.2f} of a cycle "
            f"past it (under {COVERAGE_MIN:g}): its repeat is barely seen — the seam says whether it closes; a longer take shows it repeat"]


def run_loop(
    frames_dir: Path,
    out_dir: Path,
    *,
    fps: float,
    state: str | None,
    min_len: int | None,
    max_len: int | None,
    n_out: int | None,
    seam_max: float,
    name: str,
    report_path: Path | None,
    cycle_mode: str = "auto",
    gif_fps: float = GIF_FPS_DEFAULT,
    start: int | None = None,
    length: int | None = None,
    strip_height: int = STRIP_MAX_HEIGHT,
    body_height: int | None = None,
    anchor: str | None = None,
    anchor_regions: list[motion_anchor.Box] | None = None,
    repair: str = "auto",
    facing: str = "right",
    interpolate: rife_mod.Interpolate | None = None,
    jolt_max: float | None = None,
    head_step_max: float | None = None,
    size_hold: str = "auto",
    steps: int | None = None,
) -> dict[str, Any]:
    if steps is not None and steps not in STEPS:
        raise SystemExit(f"video-loop: --steps {steps}: the cut holds {' or '.join(map(str, STEPS))} steps here")
    if size_hold not in SIZE_HOLD_MODES:
        raise SystemExit(f"video-loop: unknown --size-hold {size_hold!r}; expected one of {', '.join(SIZE_HOLD_MODES)}")
    if repair not in REPAIR_MODES:
        raise SystemExit(f"video-loop: unknown --repair {repair!r}; expected one of {', '.join(REPAIR_MODES)}")
    if facing not in FACINGS:
        raise SystemExit(f"video-loop: unknown --facing {facing!r}; expected one of {', '.join(FACINGS)}")
    if anchor is None:
        # gaits drift a few pixels over a cycle and the wrap shows it; in-place states do not
        anchor = "body" if profile_for(state).gait else "none"
    if anchor not in ANCHOR_MODES:
        raise SystemExit(f"video-loop: unknown --anchor {anchor!r}; expected one of {', '.join(ANCHOR_MODES)}")
    try:
        motion_anchor.validate_request(anchor, cycle_mode, length, anchor_regions)
    except ValueError as exc:
        raise SystemExit(f"video-loop: {exc}") from exc
    if anchor == "motion-auto" and (cycle_mode not in ("auto", "periodic") or not profile_for(state).gait
                                     or start is not None or length is not None):
        raise SystemExit("video-loop: --anchor motion-auto requires walk/run with automatic or periodic selection; no fixed cut")
    if steps is not None and anchor != "motion-auto":
        raise SystemExit("video-loop: --steps counts the steps in the cut --anchor motion-auto takes; pass --anchor motion-auto")
    if cycle_mode not in CYCLE_MODES:
        raise SystemExit(f"video-loop: unknown --cycle {cycle_mode!r}; expected one of {', '.join(CYCLE_MODES)}")
    frames_dir = frames_dir.expanduser().resolve()
    files = sorted(frames_dir.glob("*.png"))
    if len(files) < 6:
        raise SystemExit(f"video-loop: need at least 6 keyed frames in {frames_dir}, found {len(files)}")
    prof = profile_for(state)
    n = len(files)
    # A walk or run may open on a lead-in (gait_fallback.lead_in): the video model reframing a small
    # subject before it walks at the clip's size. An automatic search reads the clip after it as a clip
    # of its own, and what it finds is said in the clip's own frame numbers (`_from_lead_in`); a cut the
    # caller names (fixed, pinned) is the caller's frames, lead-in or not.
    gait_frames = [Image.open(f).convert("RGBA") for f in files] if prof.gait else None
    lead: dict[str, Any] | None = None
    if gait_frames is not None:
        whole = CutWindow.of(prof, n, fps, min_len, max_len)
        lead = gait_fallback.lead_in(gait_frames, min_lag=whole.lo, max_lag=whole.hi)
    skip = lead["frames"] if lead is not None and cycle_mode in ("auto", "periodic") else 0
    # Every search below reads its window off this one (`CutWindow`): none sets a bound of its own.
    window = CutWindow.of(prof, n - skip, fps, min_len, max_len)
    lo, hi = window.lo, window.hi
    D = distance_matrix(files)
    # The clip's steps as keyed, before `--anchor motion-auto` reads its own distance or moves a frame:
    # the hold is read on them, over the clip and over the cut (sprite_gen/video/held.py).
    clip_steps = [float(D[k, k + 1]) for k in range(n - 1)]
    masses = frame_masses(files)
    periodic_attempt: dict[str, Any] | None = None
    target = (report_path or (out_dir / f"{name}.loop.report.json")).expanduser().resolve()
    report_base = {
        "kind": "sprite-gen-video-loop-report", "frames_dir": str(frames_dir),
        "source": evidence_mod.source_identity(files, fps),
        "producer": evidence_mod.engine_identity(),
        "out_dir": str(out_dir), "state": state, "fps": fps, "frames_total": n,
        "window": [lo, hi], "profile": prof.why, "cycle_mode": cycle_mode,
        "seam_max": seam_max,
        "anchor": anchor,
        "seam_measurement": "rendered-cells" if anchor in ("motion", "motion-auto") else "source-frames",
        # How many drawings the clip shows a second, and whether it shows each for two or three frames
        # (sprite_gen/video/held.py) — over the whole clip as keyed, before any cut. A record for
        # `video-cycle-align`, which says when a held clip stretched to the set's length must be filmed again.
        "drawings": held_mod.measure(clip_steps, fps=fps),
    }
    if lead is not None:
        # `search_from`: the first clip frame the search read (0: the whole clip, or a cut the caller named).
        report_base["lead_in"] = {**lead, "search_from": skip}
    cycle = None
    shifted = False
    clip_files, clip_D = files, D
    files, D = files[skip:], D[skip:, skip:]
    try:
        if anchor == "motion-auto":
            source_frames = gait_frames[skip:]
            if size_hold == "auto":
                # A walk or run filmed from its first frame only grows or shrinks as it plays, so the
                # frame one cycle on is not the size of the first and the loop pops at the wrap. Hold
                # the clip at its first frame's size before the search (`size_hold`), so the cut is
                # chosen on frames of one size. The gait fallback below then finds nothing to undo.
                # The change is read one cycle on, so a first pose that settles into the walk is
                # not taken for a body that shrinks (gait_fallback.cycle_drift).
                measured = gait_fallback.cycle_drift(source_frames, min_lag=lo, max_lag=hi)
                hold: dict[str, Any] = {"applied": False, "min": gait_fallback.SIZE_HOLD_MIN,
                                        **{k: measured[k] for k in ("height_first_px", "height_last_px", "drift", "method",
                                                                    "lag", "pairs", "per_lag", "pose_match", "drift_fitted_line")}}
                if abs(measured["drift"]) >= gait_fallback.SIZE_HOLD_MIN:
                    pad = gait_fallback.undo_padding(source_frames, measured)
                    source_frames = gait_fallback.undo_scale(source_frames, measured, pad=pad)
                    files = gait_fallback.write_frames(source_frames, [f.name for f in files], out_dir.expanduser().resolve() / FALLBACK_FRAMES_DIR)
                    hold.update(applied=True, padding_ltrb=list(pad))
                report_base["size_hold"] = hold
            else:
                report_base["size_hold"] = {"applied": False, "why": "--size-hold off"}
            D, trajectory, analysis = auto_motion.analyse(source_frames, fps=fps)
            report_base["automatic_motion_analysis"] = analysis
            detect = dict(gait_floor=round(prof.min_seconds*fps), periodicity_min=PERIODICITY_MIN,
                          double_tolerance=GAIT_DOUBLE_TOL, double_search=GAIT_DOUBLE_SEARCH)
            try:
                moved = moved_alpha(source_frames, analysis)
                cycle = local_cycle.detect(D, trajectory, min_len=lo, max_len=hi, signals=leg_signals(source_frames),
                                           wrap_pop=wrap_pop_on(moved), held_edge=HeldEdge(moved), length_cap=window.max_len, **detect)
            except ValueError as first:
                # A front or back gait that walked toward the camera, or a slow one: one more
                # search, recorded (`gait_fallback`), and only after the first found nothing.
                drift = gait_fallback.cycle_drift(source_frames, min_lag=lo, max_lag=hi)
                fallback = {"reason": str(first), "scale_drift": {k: drift[k] for k in ("height_first_px", "height_last_px", "drift", "method")},
                            "scale_drift_min": gait_fallback.SCALE_DRIFT_MIN, "scale_undone": False}
                if abs(drift["drift"]) >= gait_fallback.SCALE_DRIFT_MIN:
                    fallback["padding_ltrb"] = list(gait_fallback.undo_padding(source_frames, drift))
                    source_frames = gait_fallback.undo_scale(source_frames, drift, pad=tuple(fallback["padding_ltrb"]))
                    files = gait_fallback.write_frames(source_frames, [f.name for f in files], out_dir.expanduser().resolve() / FALLBACK_FRAMES_DIR)
                    D, trajectory, analysis = auto_motion.analyse(source_frames, fps=fps)
                    report_base["automatic_motion_analysis"] = analysis
                    fallback["scale_undone"] = True
                # An explicit --max-len is the caller's ceiling and stays one.
                hi_long = window.past(gait_fallback.long_window(lo, len(files), fps))
                fallback["window"] = [lo, hi_long]
                report_base["gait_fallback"] = fallback
                try:
                    moved = moved_alpha(source_frames, analysis)
                    cycle = local_cycle.detect(D, trajectory, min_len=lo, max_len=hi_long,
                                               max_fraction=gait_fallback.LONG_CYCLE_FRACTION,
                                               signals=leg_signals(source_frames), wrap_pop=wrap_pop_on(moved),
                                               held_edge=HeldEdge(moved), length_cap=window.max_len, **detect)
                except ValueError as second:
                    failed = ValueError(f"{second} (also with the gait fallback: window [{lo}, {hi_long}], "
                                        f"scale drift {drift['drift']:+.1%}{', undone' if fallback['scale_undone'] else ''})")
                    # The windows the wider search measured and refused go into the report's `cycle`.
                    if hasattr(second, "diagnostics"):
                        failed.diagnostics = second.diagnostics  # type: ignore[attr-defined]
                    raise failed from first
            if steps is not None:
                cycle = _counted(cycle, steps, window=window, D=D, trajectory=trajectory, frames=source_frames, moved=moved, detect=detect)
        elif cycle_mode == "fixed":
            if start is None or length is None:
                raise SystemExit("video-loop: --cycle fixed needs --start and --length")
            cycle = fixed_cycle(D, start=start, length=length)
        elif cycle_mode == "one-shot":
            cycle = _one_shot(D, window, hi, masses)
        elif cycle_mode == "pinned":
            cycle = pinned_cycle(D, seam_max=seam_max)
        else:
            gait_floor = round(prof.min_seconds * fps) if prof.gait and prof.min_seconds > 0 else None
            cycle = detect_cycle(D, min_len=lo, max_len=hi, gait_floor=gait_floor,
                                 signals=leg_signals(gait_frames[skip:] if gait_frames is not None else [Image.open(f).convert("RGBA") for f in files]))
            cycle["kind"] = "periodic"
            floor = periodicity_floor(len(files), cycle["period_global"], partial_repeat=prof.action_seconds is not None)
            cycle["periodicity_min"] = floor
            if prof.periodic and cycle["periodicity"] < floor:
                flat = (
                    f"the period profile is flat (periodicity {cycle['periodicity']:.2f} < {floor:.3f}) in window [{lo},{hi}]"
                )
                if cycle_mode == "auto" and prof.one_shot_ok:
                    # explicit, recorded failover: the action happened once (allowed for this state),
                    # so cut rest -> excursion -> rest instead. The periodic attempt stays in the report.
                    periodic_attempt = {**cycle, "window": [lo, hi], "why_rejected": flat}
                    # A one-shot may run past the periodic window — not past the caller's ceiling.
                    cycle = _one_shot(D, window, max(hi, round(n * 0.9)), masses)
                else:
                    raise SystemExit(
                        f"video-loop: no periodic cycle found — {flat}; the motion does not repeat, widen the window, "
                        "regenerate the clip, or pass --cycle one-shot for a single performed action"
                    )
        if skip:
            cycle, shifted = _from_lead_in(cycle, skip), True
        # Whatever chose the cut — a search, a count, --cycle fixed or pinned — it is inside the caller's bounds.
        window.hold(cycle)
    except (SystemExit, ValueError) as exc:
        shutil.rmtree(out_dir.expanduser().resolve() / FALLBACK_FRAMES_DIR, ignore_errors=True)
        refused = getattr(exc, "diagnostics", cycle)
        write_loop_report(target, {**report_base, "status": "failed", "error": str(exc),
                                  "cycle": _from_lead_in(refused, skip) if skip and not shifted else refused,
                                  "periodic_attempt": periodic_attempt})
        if isinstance(exc, ValueError):
            raise SystemExit(f"video-loop: {exc}") from exc
        raise
    # The cut is in the clip's own frame numbers; the frames it reads are the clip's, scaled where the search scaled them.
    files, D = clip_files[:skip] + files, clip_D
    i, L = cycle["start"], cycle["length"]
    if "steps" in cycle:
        # A cut two steps long is one cycle: how much of a second the clip holds past it (after its lead-in).
        cycle["coverage"] = round((n - skip - L) / L, 4)
    # The same, over the cut alone: a clip held for part of its length is held where the cut is.
    report_base["cycle_drawings"] = held_mod.measure_cycle(clip_steps, start=i, length=L, fps=fps)
    # playback density, not a fixed count: a long cycle gets more frames so every state plays at
    # ~gif_fps (a fixed 12 made a 2.5 s jump hold each frame 210 ms while a 1.1 s walk held 90 ms)
    if n_out is None:
        n_out = max(GIF_FRAMES_MIN, round(L / fps * gif_fps))
    n_out = min(n_out, L)  # never ask for more distinct frames than the cycle holds

    out_dir = out_dir.expanduser().resolve()
    cycle_dir = out_dir / "cycle"
    frames: list[Image.Image] = []
    scrubbed = specks = 0
    # A walk or run cut for a `--body-height` has its frames' sizes read as filmed, for the standing height below.
    sized = body_height is not None and prof.gait
    cut_sizes = []
    for k, f in enumerate(files[i : i + L]):
        im = Image.open(f).convert("RGBA")
        if sized:
            cut_sizes.append(gait_fallback.body_size(im))
        # Motion review is pixel preserving: cleanup belongs to the keyed input (`video-frames` erases
        # the specks far from the body). The other cuts erase every loose piece of solid pixels under
        # the speck size, wherever it is: the outline's islands and a drawn shadow as well.
        if anchor not in ("motion", "motion-auto"):
            scrubbed += _scrub(im)
            im, d = drop_specks(im, alpha_over=16, diagonal=False, apart=0)
            specks += d
        frames.append(im)

    if prof.gait:
        report_base["gait"] = evidence_mod.gait_observation(frames, cycle)
    cycle_seconds = L / fps
    wrap_dx = 0
    if anchor == "body":
        wrap_dx = body_wrap_offset(frames)
        frames = ramp_frames(frames, wrap_dx)
    motion = None
    if anchor in ("motion", "motion-auto"):
        try:
            if anchor == "motion-auto":
                anchor_regions, region_report = auto_motion.discover(frames, reference_index=0)
                report_base["automatic_motion_regions"] = region_report
            correct = auto_motion.correct_cycle if anchor == "motion-auto" else motion_anchor.correct_motion
            frames, motion = correct(
                frames, anchor_regions, coarse_dx=body_wrap_offset(frames, search=motion_anchor.COARSE_SEARCH),
            )
        except ValueError as exc:
            error = f"video-loop: {exc}"
            shutil.rmtree(out_dir / FALLBACK_FRAMES_DIR, ignore_errors=True)
            write_loop_report(target, {**report_base, "status": "failed", "error": error, "cycle": cycle})
            raise SystemExit(error) from exc
        report_base["motion_anchor"] = motion
    if anchor in ("none", "body"):
        from sprite_gen.video.source import RECIPE
        report_base["source_projection"] = {
            "recipe": RECIPE, "wrap_dx_px": wrap_dx,
            "before_repair_pixels_sha256": [evidence_mod.digest(f.tobytes()) for f in frames],
        }
    if prof.gait:
        # The ghost screen of the cut as filmed (docs/loop-repair.md section 4), read before the jump repair: each
        # filmed ghost it names is a target of that repair, which gives it way to a clean frame where there is one.
        # A loop delivered as cut, never aligned, would show it otherwise.
        report_base["ghost_screen"] = ghost_screen(frames)
    # Each cut frame given way to the frame beside it, as filmed: the seam is read on it there (`seam_as_filmed`).
    as_filmed: dict[int, Image.Image] = {}
    if repair != "off" and prof.gait:
        report_base["jump_repair"] = None
        filmed = frames
        try:
            frames, report_base["jump_repair"] = _repair_jumps(frames, interpolate, facing=facing, required=repair == "on",
                                                               screen=report_base["ghost_screen"])
        except (ValueError, rife_mod.RifeUnavailable) as exc:
            fix = (f"install RIFE (`{rife_mod.INSTALL_COMMAND}`), or pass --repair auto to cut it as filmed with a warning"
                   if isinstance(exc, rife_mod.RifeNotInstalled) else "fix RIFE, or pass --repair off to cut it as filmed")
            error = (f"video-loop: {exc}; the loop has a frame to make (after a jump, or for a filmed ghost between two clean "
                     f"frames) — {fix} (docs/loop-repair.md)")
            shutil.rmtree(out_dir / FALLBACK_FRAMES_DIR, ignore_errors=True)
            write_loop_report(target, {**report_base, "status": "failed", "error": error, "cycle": cycle})
            raise SystemExit(error) from exc
        # What became of each filmed ghost: given way (the cell and what it shows now) or kept, no clean frame beside it.
        ghost_rounds = [r for r in report_base["jump_repair"]["rounds"] if r.get("why") == "ghost"]
        # A cell given way to the frame beside it is that frame shown twice in a row — a step of nothing and a step of two,
        # wherever the ghost was. The seam gate asks whether the cut closes, so it reads that cell as filmed (`seam_as_filmed`):
        # at the wrap the step of two would read as a cut that does not close, and the step of nothing as one that closes
        # whatever the cut. Only a frame made (RIFE's, for a jump or a ghost) has the gate read the rendered cells.
        as_filmed = {r["target"]: filmed[r["target"]] for r in ghost_rounds if isinstance(r["taken"], dict)}
        if as_filmed:
            report_base["seam_as_filmed"] = sorted(as_filmed)
        if set(report_base["jump_repair"]["replaced"]) - set(as_filmed):
            report_base["seam_measurement"] = "rendered-cells"
        report_base["ghost_given_way"] = [{"frame": r["target"], "ghost": r["original"]["ghost"], "taken": r["taken"]}
                                          for r in ghost_rounds if r["taken"] is not None]
        report_base["ghost_kept"] = [{"frame": r["target"], "ghost": r["original"]["ghost"]} for r in ghost_rounds if r["taken"] is None]
        for line in _ghost_lines(report_base["jump_repair"]):
            print(f"video-loop: warning: {line}", file=sys.stderr)
        for r in report_base["jump_repair"].get("rounds", []):
            if r["outcome"] == "accepted" and r["look"]:
                print(f"video-loop: warning: frame {r['target']} was {'given way for a filmed ghost' if r['why'] == 'ghost' else 'repaired'} "
                      "with RIFE's frame between its neighbours, which may "
                      f"cross-fade two drawings inside its outline (crossfade {r['proposal']['crossfade']:.4f}); kept, a reading to "
                      "look at — see it in the loop, or cut it with --repair off (docs/loop-repair.md section 4)", file=sys.stderr)
        if "rife" in report_base["jump_repair"]:
            print(f"video-loop: warning: a jump frame was not repaired ({report_base['jump_repair']['score_max_before']:.2f}x "
                  f"the median step) — RIFE is not installed, so the loop is cut as filmed; run `{rife_mod.INSTALL_COMMAND}` "
                  "and cut it again (docs/loop-repair.md)", file=sys.stderr)
    else:
        report_base["jump_repair"] = {"applied": False, "why": "--repair off" if repair == "off" else f"not a gait state ({state})"}
    if prof.gait:
        # The jolt is measured on the loop as it will play — after the repair — and reported on
        # every walk and run (docs/loop-repair.md section 3). Beyond the reference bounds it is a
        # warning line; it fails the loop only against a bound the caller passed (--jolt-max /
        # --head-step-max), and never with --repair off, which cuts and reports as filmed. A loop
        # whose repair could not run (no RIFE) is gated as filmed, and the failure says why.
        jolt = repair_mod.measure_jolt(frames, facing=facing)
        reference = {"jolt_max": repair_mod.JOLT_REFERENCE, "head_step_max": repair_mod.HEAD_STEP_REFERENCE}
        warnings = repair_mod.jolt_verdict(jolt, **reference)
        warnings += repair_mod.seam_pop_verdict(jolt, head_step_max=repair_mod.HEAD_STEP_REFERENCE)
        # The held side below the top, read on the source frames when the cut was chosen again (local_cycle).
        warnings += repair_mod.held_edge_verdict(cycle.get("seam_pop"))
        warnings += coverage_verdict(cycle)
        gated = repair != "off" and (jolt_max is not None or head_step_max is not None)
        over = repair_mod.jolt_verdict(jolt, jolt_max=jolt_max, head_step_max=head_step_max) if gated else []
        report_base["jolt"] = {**jolt, "reference": reference, "warnings": warnings,
                               "gate": {"jolt_max": jolt_max, "head_step_max": head_step_max} if gated else None,
                               "gated": gated, "over": over, "passed": not over,
                               "measured": "after the jump repair" if report_base["jump_repair"].get("replaced") else "as filmed"}
        if over:
            error = (f"video-loop: loop jolts — {'; '.join(over)} ({cycle.get('kind', 'periodic')} length {L} frames from {i}"
                     f"{', after repairing frames ' + str(report_base['jump_repair']['replaced']) if report_base['jump_repair'].get('replaced') else ''}); "
                     "the motion does not play smoothly — regenerate the clip"
                     f"{' (the jump repair did not run: RIFE is not installed — ' + rife_mod.INSTALL_COMMAND + ')' if 'rife' in report_base['jump_repair'] else ''}")
            shutil.rmtree(out_dir / FALLBACK_FRAMES_DIR, ignore_errors=True)
            write_loop_report(target, {**report_base, "status": "failed", "error": error, "cycle": cycle})
            raise SystemExit(error)
        for line in warnings:
            print(f"video-loop: warning: {line} (reference bound; the loop is kept — docs/loop-repair.md)", file=sys.stderr)
        if "ghost_given_way" not in report_base:
            # The jump repair did not run (--repair off): a filmed ghost is delivered as cut, named here;
            # `video-cycle-align` screens its source again and takes a clean frame beside it.
            for g in report_base["ghost_screen"]["ghosts"]:
                print(f"video-loop: warning: frame {g['frame']} of the cut (cycle/frame-{g['frame']:03d}.png) carries a part-covered band "
                      f"over {100 * g['ghost']:.2f} % of its body, at least {rife_mod.GHOST_THICK} px thick — a filmed ghost; delivered as cut "
                      "it shows (--repair off), and video-cycle-align takes a clean frame beside it (docs/loop-repair.md)", file=sys.stderr)
        if not report_base["ghost_screen"]["reads"]:
            print(f"video-loop: warning: the ghost screen does not read this cut — {report_base['ghost_screen']['why']}; no frame "
                  "of it is named a ghost, here or in video-cycle-align, so look at cycle/ (docs/loop-repair.md)", file=sys.stderr)
    cycle_dir.mkdir(parents=True, exist_ok=True)
    for old in cycle_dir.glob("frame-*.png"):
        old.unlink()
    shutil.rmtree(out_dir / CYCLE_SOURCE_DIR, ignore_errors=True)
    # A new cut makes a follow-through over the old strip stale (`video-follow` reads this source).
    (out_dir / FOLLOW_SOURCE).unlink(missing_ok=True)
    for k, im in enumerate(frames):
        im.save(cycle_dir / f"frame-{k:03d}.png")
    # The standing height is the base still's pose as filmed, the clip's first frame — but a video model that
    # reframes the subject after it films that pose at another size than the walk. Where the cut is filmed
    # SIZE_HOLD_MIN or more larger or smaller than the first frame (gait_fallback.size_change: what its height,
    # mass and breadth all agree on, so not a pose), the standing height is read on the cut's own first frame.
    # A lead-in is such a reframing, and so is one too small to open a lead-in.
    standing_frame = 0
    if sized:
        report_base["cut_size"] = gait_fallback.size_change(gait_fallback.body_size(Image.open(files[0]).convert("RGBA")), cut_sizes)
        if abs(report_base["cut_size"]["change"]) >= gait_fallback.SIZE_HOLD_MIN:
            standing_frame = i
    strip_of = partial(build_strip, max_height=strip_height, cycle_seconds=cycle_seconds, body_height=body_height, anchor="feet" if anchor == "feet" else "none", kind=str(cycle.get("kind") or "periodic"),
                       standing_src=standing_height(files[standing_frame], standing_frame) if body_height is not None else None,
                       standing_frame=standing_frame)
    strip, strip_meta = strip_of(frames)
    # The cut as its seam is read: each cell given way to the frame beside it as filmed (`seam_as_filmed`).
    seam_frames = [as_filmed.get(k, f) for k, f in enumerate(frames)]
    strip_meta["source_cut"] = {"source": report_base["source"], "start": i, "length": L,
                                "samples": [i + k for k in strip_meta["sample_indices"]]}
    # The scaled-back frames are read for the last time above; the cycle cells keep them.
    shutil.rmtree(out_dir / FALLBACK_FRAMES_DIR, ignore_errors=True)
    if state:
        # `video-cycle-align` reads the gait floor of this state when it screens a loop for two cycles.
        strip_meta["state"] = str(state).strip().lower()
    if "steps" in cycle:
        # A cut whose steps are known — counted (`--steps`) or two candidate lengths taken so a held part
        # closes (local_cycle._held_rank): `video-cycle-align` reads a return half way as its step.
        strip_meta["steps"] = cycle["steps"]["count"]
    # `video-cycle-align` reads the hold here, over the cut (`cycle_drawings`) and over the clip
    # (`drawings`, where the cut is too short to read): read on the keyed steps, since `--anchor
    # motion-auto` moves each frame of a pair apart in the cut it writes (sprite_gen/video/held.py).
    strip_meta["drawings"] = {k: report_base["drawings"][k] for k in ("hold", "drawings_per_second", "contrast", "frames")}
    strip_meta["cycle_drawings"] = {k: report_base["cycle_drawings"][k] for k in ("start", "length", "steps", "hold", "drawings_per_second", "contrast")
                                    } | ({"why": report_base["cycle_drawings"]["why"]} if "why" in report_base["cycle_drawings"] else {})
    # A cut frame that is no longer the frame as filmed for a filmed ghost, and one kept with no clean frame beside
    # it: `cycle/` is the alignment's material (`cycle.source/`), whose screen no longer sees a ghost given way, so the
    # strip says it, and an alignment carries it over (frames of the cut).
    for key in ("ghost_given_way", "ghost_kept"):
        if report_base.get(key):
            strip_meta[key] = report_base[key]
    if motion is not None:
        strip_meta["foot_anchor"] = anchor
        strip_meta["motion_anchor"] = motion
    if anchor == "body":
        strip_meta["foot_anchor"] = "body"
        strip_meta["wrap_dx_px"] = wrap_dx
        # the wrap as it now plays: last ramped frame -> first, against an ordinary step (a cell given way read as filmed)
        Dr = _distances(np.stack([_small_features(f) for f in seam_frames]))
        inner = float(np.mean([Dr[k, k + 1] for k in range(len(frames) - 1)])) if len(frames) > 1 else 0.0
        strip_meta["seam_ratio_after_anchor"] = round(float(Dr[len(frames) - 1, 0]) / inner, 4) if inner > 0 else None
    # The GIF/WebP are cut from the strip's cells. A cycle longer than the cell cap was
    # subsampled there, so asking for more frames than cells repeats cells back to back
    # and the GIF writer merges the identical neighbours — the file then holds fewer
    # frames than requested and verification refused it (2026-09-20: a 68-frame jump cycle
    # capped at 64 cells came back as a 64-frame GIF "expected 68").
    n_out = min(n_out, int(strip_meta["frames"]))
    strip_path = out_dir / f"{name}.strip.png"
    strip.save(strip_path)
    atomic_write_text(out_dir / f"{name}.strip.json", json.dumps(strip_meta, indent=2) + "\n")

    # resampled GIF/WebP frames: same crop as the strip, n_out evenly across the cycle
    idx = [min(L - 1, i2) for i2 in (round(k * L / n_out) for k in range(n_out))]
    pick = resampled_cells(strip, strip_meta, idx, L)
    seam_idx = [i + j for j in idx]
    resampled_adjacent = float(np.mean([D[seam_idx[k], seam_idx[k + 1]] for k in range(len(seam_idx) - 1)]))
    resampled_seam = float(D[seam_idx[-1], seam_idx[0]])
    if report_base["seam_measurement"] == "rendered-cells":
        # Gate the actual corrected/repaired/resampled strip cells, with the same limit — a cell given way to the frame
        # beside it as filmed (`seam_as_filmed`), on the strip the cut makes with those frames.
        flat = np.stack([_small_features(im) for im in (resampled_cells(*strip_of(seam_frames), idx, L) if as_filmed else pick)])
        resampled_adjacent = float(np.abs(flat[1:] - flat[:-1]).mean())
        resampled_seam = float(np.abs(flat[-1] - flat[0]).mean())
    seam_ratio = resampled_seam / resampled_adjacent if resampled_adjacent > 0 else math.inf
    delay_ms = max(20, round(1000 * cycle_seconds / n_out))
    gif_path = out_dir / f"{name}.gif"
    webp_path = out_dir / f"{name}.webp"
    if cycle["kind"] == "pinned":
        if cycle["pin_error"] > cycle["pin_tolerance"]:
            error = (
                f"video-loop: the pinned clip does not end on its first frame (pin error {cycle['pin_error']:.4f} "
                f"exceeds {cycle['pin_tolerance']:.4f}); the loop does not close — regenerate the clip with "
                "--last-frame set to its first frame"
            )
            write_loop_report(target, {**report_base, "status": "failed", "error": error, "cycle": cycle,
                                      "resampled_seam": resampled_seam,
                                      "resampled_inner_mean_adjacent": resampled_adjacent,
                                      "resampled_seam_ratio": seam_ratio})
            raise SystemExit(error)
    elif seam_ratio > seam_max:
        error = (
            f"video-loop: loop seam ratio {seam_ratio:.2f} exceeds {seam_max} "
            f"({cycle['kind']} length {L} frames from {i}); the cycle does not close — "
            "regenerate with a complete return to the starting pose"
        )
        write_loop_report(target, {**report_base, "status": "failed", "error": error,
                                  "cycle": cycle, "periodic_attempt": periodic_attempt,
                                  "resampled_seam": resampled_seam,
                                  "resampled_inner_mean_adjacent": resampled_adjacent,
                                  "resampled_seam_ratio": seam_ratio})
        raise SystemExit(error)
    save_clean_gif(pick, gif_path, duration_ms=delay_ms, loop=0, alpha_threshold=128)
    write_webp(pick, webp_path, delay_ms=delay_ms, workdir=out_dir / ".webp-frames")
    shutil.rmtree(out_dir / ".webp-frames", ignore_errors=True)
    # A filmed ghost given way to the frame beside it is that frame shown twice in a row: one frame of the GIF or WebP
    shown = shown_runs(pick)
    gif_report = verify_animation(gif_path, expect_frames=shown, check_stale=False)
    webp_report = verify_animation(webp_path, expect_frames=shown, check_stale=True)

    payload = {
        **report_base,
        "kind": "sprite-gen-video-loop-report",
        "frames_dir": str(frames_dir),
        "out_dir": str(out_dir),
        "state": state,
        "fps": fps,
        "frames_total": n,
        "window": [lo, hi],
        "profile": prof.why,
        "cycle_mode": cycle_mode,
        "cycle": cycle,
        "periodic_attempt": periodic_attempt,
        "cycle_seconds": round(cycle_seconds, 4),
        "n_out": n_out,
        "gif_fps": gif_fps,
        "delay_ms": delay_ms,
        "status": "passed",
        "resampled_seam": resampled_seam,
        "resampled_inner_mean_adjacent": resampled_adjacent,
        "resampled_seam_ratio": round(seam_ratio, 4),
        "seam_max": seam_max,
        "scrubbed_rgb_pixels": scrubbed,
        "specks_dropped": specks,
        "strip": {"path": str(strip_path), **strip_meta},
        "gif": gif_report,
        "webp": webp_report,
    }
    write_loop_report(target, payload)
    payload["report"] = str(target)
    return payload


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--frames-dir", required=True, type=Path, help="keyed RGBA frames from `sprite-gen video-frames` (…/keyed)")
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--fps", type=float, default=24.0, help="frame rate of the keyed frames (from the frames report)")
    parser.add_argument("--state", help="motion state (idle/walk/run/jump/attack) — selects the detection window")
    parser.add_argument("--min-len", type=int, help="override: minimum cycle length in frames, on every path that sets one (a cut shorter fails)")
    parser.add_argument("--max-len", type=int, help="override: maximum cycle length in frames, on every path that sets one (a cut longer fails)")
    parser.add_argument("--n-out", type=int, help="frames in the GIF/WebP (default: cycle seconds x --gif-fps)")
    parser.add_argument("--gif-fps", type=float, default=GIF_FPS_DEFAULT, help=f"GIF/WebP playback density (default {GIF_FPS_DEFAULT:g}); every state plays at this rate regardless of cycle length")
    parser.add_argument("--seam-max", type=float, default=SEAM_RATIO_MAX, help=f"loop seam gate (default {SEAM_RATIO_MAX})")
    parser.add_argument("--cycle", choices=CYCLE_MODES, default="auto", help="auto: periodic first, one-shot failover for action states (recorded in the report); periodic / one-shot force one detector; fixed cuts exactly --start/--length (no detection, reported as kind=fixed); pinned: the whole clip but its last frame, for a clip pinned to end on its first frame (the gate is that pin)")
    parser.add_argument("--start", type=int, help="fixed cut: first keyed frame of the cycle (with --cycle fixed)")
    parser.add_argument("--length", type=int, help="fixed cut: cycle length in frames (with --cycle fixed)")
    parser.add_argument("--strip-height", type=int, default=STRIP_MAX_HEIGHT, help=f"cell/strip/GIF height cap in px (default {STRIP_MAX_HEIGHT}); the cycle is scaled down to fit, and never up unless --body-height asks for it")
    parser.add_argument("--body-height", type=int, help="scale so the STANDING height (the subject in the clip's first frame, i.e. the base still's pose) is this many px — the same value across states gives the same character size; --strip-height stays the cap")
    parser.add_argument("--anchor", choices=ANCHOR_MODES, default=None, help="motion-auto: automatic stable regions, local repeat selection and XY ramp (walk/run); motion: fixed cut with explicit regions; body (default for walk/run): measure the last-to-first head-and-torso offset once and spread it as a ramp over the cycle; feet: remove in-canvas drift (a straight-line trend) so every cell stands on the mean foot line; none: leave placement as filmed (default for other states)")
    parser.add_argument("--anchor-region", type=motion_anchor.parse_region, action="append", help="motion anchor only: repeat twice with head then torso x0,y0,x1,y1 in the first selected frame; requires --cycle fixed and at least 6 frames")
    parser.add_argument("--repair", choices=REPAIR_MODES, default="auto", help="auto (default): propose RIFE's frame between the neighbours of a jump (a step 1.4x the median, whole body or the hair behind it); adopt only without smear/outline faults, at most 3 calls and never two adopted frames side by side (docs/loop-repair.md). Rejected proposals keep the original. Missing RIFE keeps the filmed loop with a warning (`sprite-gen rife install`); on: the same repair, but no RIFE fails the loop; off: cut as filmed")
    parser.add_argument("--jolt-max", type=float, default=None, help=f"walk/run: fail the repaired loop when its jolt index (how far each step strays from its neighbours' mean, over the median step) exceeds this. Default: no gate — the index is reported and a value over {repair_mod.JOLT_REFERENCE} is a warning line")
    parser.add_argument("--head-step-max", type=float, default=None, help=f"walk/run: fail the repaired loop when the head's largest sideways move in one frame exceeds this %% of the body height. Default: no gate — reported, and over {repair_mod.HEAD_STEP_REFERENCE} is a warning line")
    parser.add_argument("--facing", choices=FACINGS, default="right", help="which way the body faces in the frames (default right): the hair the jump search watches is behind it")
    parser.add_argument("--size-hold", choices=SIZE_HOLD_MODES, default="auto", help="--anchor motion-auto: auto (default) scales a clip whose height, read one cycle on (the same pose a cycle later), changes by 1 %% or more over the clip back to its first frame's size before the cycle search, so the loop's last frame is the size of its first (recorded as size_hold, with the evidence); off: search the frames as filmed")
    parser.add_argument("--steps", type=int, choices=STEPS, default=None,
                        help="--anchor motion-auto: how many steps the cut it takes without this holds, as counted by whoever looked "
                             "at the loop (how often each foot lands) — the report's `cycle.step_screen` names a cut that may be one "
                             "step. 1: the cut is one step, so the walk is cut again two of its lengths long (the window [2L-1, 2L+1], "
                             "not bounded by half the clip but held inside --min-len/--max-len: a window that leaves none of it "
                             "fails), recorded `cycle.steps`; 2: the cut is kept, recorded. Either way the strip "
                             "metadata says `steps: 2`, which `video-cycle-align` reads")
    parser.add_argument("--name", default="loop", help="basename for strip/gif/webp outputs")
    parser.add_argument("--report", type=Path)


def run(**kwargs: object) -> int:
    payload = run_loop(
        Path(str(kwargs["frames_dir"])), Path(str(kwargs["out_dir"])),
        fps=float(kwargs.get("fps") or 24.0), state=kwargs.get("state"),  # type: ignore[arg-type]
        min_len=kwargs.get("min_len"), max_len=kwargs.get("max_len"), n_out=kwargs.get("n_out"),  # type: ignore[arg-type]
        seam_max=float(kwargs.get("seam_max") or SEAM_RATIO_MAX), name=str(kwargs.get("name") or "loop"), report_path=kwargs.get("report"),  # type: ignore[arg-type]
        cycle_mode=str(kwargs.get("cycle") or "auto"), gif_fps=float(kwargs.get("gif_fps") or GIF_FPS_DEFAULT),
        start=kwargs.get("start"), length=kwargs.get("length"), strip_height=int(kwargs.get("strip_height") or STRIP_MAX_HEIGHT),  # type: ignore[arg-type]
        body_height=kwargs.get("body_height"),  # type: ignore[arg-type]
        anchor=kwargs.get("anchor"),  # None resolves by state inside run_loop
        anchor_regions=kwargs.get("anchor_region"),
        repair=str(kwargs.get("repair") or "auto"), facing=str(kwargs.get("facing") or "right"),
        jolt_max=kwargs.get("jolt_max"), head_step_max=kwargs.get("head_step_max"),  # type: ignore[arg-type]
        size_hold=str(kwargs.get("size_hold") or "auto"), steps=kwargs.get("steps"),  # type: ignore[arg-type]
    )
    summary = {k: payload[k] for k in ("state", "frames_total", "window", "cycle_seconds", "n_out", "delay_ms", "resampled_seam_ratio", "specks_dropped", "report")}
    summary["cycle"] = {k: payload["cycle"].get(k) for k in ("kind", "start", "length", "period_global", "ratio", "review_recommended", "half_period_guard", "fundamental")}
    summary["drawings"] = {k: payload["drawings"][k] for k in ("hold", "drawings_per_second")}
    if payload["periodic_attempt"]:
        summary["periodic_attempt"] = payload["periodic_attempt"]["why_rejected"]
    if payload.get("motion_anchor", {}).get("applied") is False:
        summary["motion_anchor"] = payload["motion_anchor"]
    if payload.get("jolt"):
        summary["jolt"] = {"index": payload["jolt"]["index"], "warnings": payload["jolt"]["warnings"],
                           "head_x_step_max_pct": payload["jolt"]["head"].get("x", {}).get("step_max_pct"),
                           "seam_pop": payload["jolt"]["seam_pop"].get("pop")}
    if payload["cycle"].get("seam_pop", {}).get("applied"):
        summary["cycle"]["seam_pop"] = payload["cycle"]["seam_pop"]
    if "steps" in payload["cycle"]:
        summary["cycle"]["steps"] = payload["cycle"]["steps"]
        summary["cycle"]["coverage"] = payload["cycle"]["coverage"]
    if "step_screen" in payload["cycle"]:
        summary["cycle"]["step_screen"] = payload["cycle"]["step_screen"]
    if payload.get("ghost_screen", {}).get("ghosts") or payload.get("ghost_screen", {}).get("reads") is False:
        summary["ghost_screen"] = payload["ghost_screen"]
    for key in ("ghost_given_way", "ghost_kept"):
        if payload.get(key):
            summary[key] = payload[key]
    if payload.get("jump_repair", {}).get("replaced"):
        summary["jump_repair"] = {k: payload["jump_repair"][k] for k in ("replaced", "score_max_before", "score_max_after")}
    summary["strip"] = {k: payload["strip"][k] for k in ("path", "frames", "w", "h", "body_h", "delay_ms")}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="sprite-gen video-loop", description=__doc__)
    add_arguments(parser)
    return run(**vars(parser.parse_args(argv)))


if __name__ == "__main__":
    raise SystemExit(main())
